// Supabase Configuration
import { createClient } from '@supabase/supabase-js'

// Supabase project configuration
// You'll need to replace these with your actual Supabase project credentials
const supabaseUrl = process.env.SUPABASE_URL || 'YOUR_SUPABASE_URL'
const supabaseAnonKey = process.env.SUPABASE_ANON_KEY || 'YOUR_SUPABASE_ANON_KEY'

// Create Supabase client
export const supabase = createClient(supabaseUrl, supabaseAnonKey)

// Database table names
export const TABLES = {
  PRODUCTS: 'products',
  USERS: 'users',
  ORDERS: 'orders',
  ORDER_ITEMS: 'order_items',
  CATEGORIES: 'categories'
}

// Helper functions for common operations
export const supabaseHelpers = {
  // Products
  async getAllProducts() {
    const { data, error } = await supabase
      .from(TABLES.PRODUCTS)
      .select('*')
      .eq('active', true)
      .order('created_at', { ascending: false })
    
    if (error) throw error
    return data
  },

  async getFeaturedProducts() {
    const { data, error } = await supabase
      .from(TABLES.PRODUCTS)
      .select('*')
      .eq('featured', true)
      .eq('active', true)
      .order('created_at', { ascending: false })
    
    if (error) throw error
    return data
  },

  async getProductsByCategory(category) {
    const { data, error } = await supabase
      .from(TABLES.PRODUCTS)
      .select('*')
      .eq('category', category)
      .eq('active', true)
      .order('created_at', { ascending: false })
    
    if (error) throw error
    return data
  },

  async createProduct(productData) {
    const { data, error } = await supabase
      .from(TABLES.PRODUCTS)
      .insert([productData])
      .select()
    
    if (error) throw error
    return data[0]
  },

  async updateProduct(id, updates) {
    const { data, error } = await supabase
      .from(TABLES.PRODUCTS)
      .update(updates)
      .eq('id', id)
      .select()
    
    if (error) throw error
    return data[0]
  },

  async deleteProduct(id) {
    const { data, error } = await supabase
      .from(TABLES.PRODUCTS)
      .delete()
      .eq('id', id)
    
    if (error) throw error
    return data
  },

  // Users
  async createUser(userData) {
    const { data, error } = await supabase
      .from(TABLES.USERS)
      .insert([userData])
      .select()
    
    if (error) throw error
    return data[0]
  },

  async getUserByEmail(email) {
    const { data, error } = await supabase
      .from(TABLES.USERS)
      .select('*')
      .eq('email', email)
      .single()
    
    if (error && error.code !== 'PGRST116') throw error
    return data
  },

  // Orders
  async createOrder(orderData) {
    const { data, error } = await supabase
      .from(TABLES.ORDERS)
      .insert([orderData])
      .select()
    
    if (error) throw error
    return data[0]
  },

  async getOrdersByUser(userId) {
    const { data, error } = await supabase
      .from(TABLES.ORDERS)
      .select(`
        *,
        order_items (
          *,
          products (*)
        )
      `)
      .eq('user_id', userId)
      .order('created_at', { ascending: false })
    
    if (error) throw error
    return data
  },

  async getAllOrders() {
    const { data, error } = await supabase
      .from(TABLES.ORDERS)
      .select(`
        *,
        order_items (
          *,
          products (*)
        ),
        users (name, email)
      `)
      .order('created_at', { ascending: false })
    
    if (error) throw error
    return data
  }
}