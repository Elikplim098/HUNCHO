# TSP Product Images Guide

## Overview
The website is set up with a sophisticated image system that displays beautiful CSS-based placeholders until real product images are added. Each product has designated image paths and fallback placeholders.

## Image Structure

### Directory Structure
```
public/
├── assets/
│   └── products/
│       ├── tsp-black-tee.jpg
│       ├── tsp-white-tee.jpg
│       ├── tsp-hoodie-black.jpg
│       ├── tsp-zip-hoodie-grey.jpg
│       ├── tsp-joggers-black.jpg
│       ├── tsp-cargo-khaki.jpg
│       ├── tsp-cap-black.jpg
│       ├── tsp-beanie-grey.jpg
│       ├── tsp-backpack-black.jpg
│       ├── tsp-tank-white.jpg
│       ├── tsp-sweatshirt-navy.jpg
│       ├── tsp-shorts-black.jpg
│       ├── tsp-oversized-grey.jpg
│       ├── tsp-pullover-purple.jpg
│       ├── tsp-track-black.jpg
│       └── tsp-bucket-black.jpg
```

## Current Products & Image Requirements

### T-Shirts
1. **TSP Classic Black Tee** - `tsp-black-tee.jpg`
2. **TSP White Tee** - `tsp-white-tee.jpg`
3. **TSP Tank Top White** - `tsp-tank-white.jpg`
4. **TSP Oversized Tee Grey** - `tsp-oversized-grey.jpg`

### Hoodies
1. **TSP Street Hoodie Black** - `tsp-hoodie-black.jpg`
2. **TSP Zip Hoodie Grey** - `tsp-zip-hoodie-grey.jpg`
3. **TSP Sweatshirt Navy** - `tsp-sweatshirt-navy.jpg`
4. **TSP Pullover Hoodie Purple** - `tsp-pullover-purple.jpg`

### Pants
1. **TSP Joggers Black** - `tsp-joggers-black.jpg`
2. **TSP Cargo Pants Khaki** - `tsp-cargo-khaki.jpg`
3. **TSP Shorts Black** - `tsp-shorts-black.jpg`
4. **TSP Track Pants Black** - `tsp-track-black.jpg`

### Accessories
1. **TSP Snapback Cap Black** - `tsp-cap-black.jpg`
2. **TSP Beanie Grey** - `tsp-beanie-grey.jpg`
3. **TSP Backpack Black** - `tsp-backpack-black.jpg`
4. **TSP Bucket Hat Black** - `tsp-bucket-black.jpg`

## Image Specifications

### Recommended Dimensions
- **Width**: 800px minimum
- **Height**: 1000px minimum
- **Aspect Ratio**: 4:5 (portrait) or 1:1 (square)
- **Format**: JPG or PNG
- **File Size**: Under 500KB for optimal loading

### Photography Guidelines
1. **Clean Background**: White or light grey background
2. **Good Lighting**: Even, natural lighting preferred
3. **Product Focus**: Item should fill 70-80% of frame
4. **Multiple Angles**: Consider front, back, and detail shots
5. **Model or Flat Lay**: Either styled on model or laid flat
6. **TSP Logo Visible**: Ensure logo/branding is clearly visible

## How to Add Images

### Step 1: Prepare Images
1. Resize images to recommended dimensions
2. Optimize file size (use tools like TinyPNG)
3. Name files exactly as specified above
4. Ensure high quality and good lighting

### Step 2: Upload Images
1. Place images in `public/assets/products/` directory
2. Use exact filenames as listed above
3. Ensure file extensions match (.jpg)

### Step 3: Test
1. Refresh the products page
2. Images should automatically replace placeholders
3. Check that all images load correctly
4. Test on mobile devices

## Placeholder System

### How It Works
- Each product has a CSS-based placeholder with TSP logo
- Placeholders are category-color coded:
  - **T-Shirts**: Blue gradient
  - **Hoodies**: Purple gradient  
  - **Pants**: Green gradient
  - **Accessories**: Orange gradient
- Real images automatically replace placeholders when available
- Fallback to placeholder if image fails to load

### Customizing Placeholders
To modify placeholder appearance, edit the CSS in `public/products.js`:
```css
.product-placeholder[data-category="t-shirts"] {
    background: linear-gradient(135deg, #e3f2fd 0%, #bbdefb 100%);
}
```

## Adding New Products

### Step 1: Add Product Data
Edit `public/products.js` and add new product object:
```javascript
{
    id: 17,
    name: 'TSP New Product',
    description: 'Product description',
    price: 99.00,
    category: 't-shirts',
    image: 'assets/products/tsp-new-product.jpg',
    placeholder: 'tshirt-new',
    sizes: ['S', 'M', 'L', 'XL'],
    colors: ['Black'],
    featured: false
}
```

### Step 2: Add Product Image
1. Create image following specifications above
2. Name it `tsp-new-product.jpg`
3. Place in `public/assets/products/`

## Image Optimization Tips

### Tools for Optimization
- **TinyPNG**: Online compression tool
- **ImageOptim**: Mac app for optimization
- **Squoosh**: Google's web-based image optimizer
- **Photoshop**: Save for Web feature

### Best Practices
1. Use JPG for photos, PNG for graphics with transparency
2. Compress images without losing quality
3. Consider WebP format for modern browsers
4. Use responsive images for different screen sizes
5. Implement lazy loading for better performance

## Troubleshooting

### Image Not Showing
1. Check file path and name exactly match
2. Verify image is in correct directory
3. Check file permissions
4. Clear browser cache
5. Check browser console for errors

### Image Quality Issues
1. Ensure minimum dimensions are met
2. Check compression settings
3. Verify image isn't pixelated or blurry
4. Consider higher resolution source

### Performance Issues
1. Optimize file sizes
2. Implement lazy loading
3. Use appropriate image formats
4. Consider CDN for image delivery

## Future Enhancements

### Planned Features
1. **Multiple Images**: Support for product galleries
2. **Zoom Functionality**: Image zoom on hover/click
3. **360° Views**: Interactive product rotation
4. **Color Variants**: Different images for color options
5. **Size Charts**: Visual size guide overlays

### Technical Improvements
1. **WebP Support**: Modern image format
2. **Lazy Loading**: Improved performance
3. **Progressive Loading**: Blur-to-sharp effect
4. **Image CDN**: Faster global delivery
5. **Auto-Optimization**: Automatic image processing

## Contact
For questions about product images or technical issues, contact the development team.