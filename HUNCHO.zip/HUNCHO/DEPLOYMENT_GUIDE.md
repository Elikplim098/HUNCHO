# 🚀 TSP Clothing Brand - Web Hosting Deployment Guide

## 🎯 Quick Deployment Options

### Option 1: Vercel (Recommended - Free & Easy)
### Option 2: Netlify (Great for Static + Serverless)
### Option 3: Railway (Full-Stack Hosting)
### Option 4: Render (Free Tier Available)
### Option 5: Heroku (Paid but Reliable)

---

## 🌟 Option 1: Vercel Deployment (Recommended)

**Best for**: Full-stack apps with serverless functions
**Cost**: Free tier available
**Setup Time**: 5-10 minutes

### Step 1: Prepare Your Project

1. **Create Vercel configuration**:

```json
// vercel.json
{
  "version": 2,
  "builds": [
    {
      "src": "server-supabase.js",
      "use": "@vercel/node"
    }
  ],
  "routes": [
    {
      "src": "/api/(.*)",
      "dest": "/server-supabase.js"
    },
    {
      "src": "/(.*)",
      "dest": "/public/$1"
    }
  ],
  "env": {
    "NODE_ENV": "production"
  }
}
```

2. **Update package.json**:

```json
{
  "scripts": {
    "start": "node server-supabase.js",
    "build": "echo 'No build step required'",
    "vercel-build": "echo 'Build completed'"
  }
}
```

### Step 2: Deploy to Vercel

1. **Install Vercel CLI**:
   ```bash
   npm install -g vercel
   ```

2. **Login to Vercel**:
   ```bash
   vercel login
   ```

3. **Deploy**:
   ```bash
   vercel
   ```

4. **Set Environment Variables**:
   ```bash
   vercel env add SUPABASE_URL
   vercel env add SUPABASE_ANON_KEY
   vercel env add SUPABASE_SERVICE_ROLE_KEY
   ```

5. **Redeploy with environment variables**:
   ```bash
   vercel --prod
   ```

### Step 3: Configure Domain (Optional)

1. In Vercel dashboard, go to your project
2. Click "Domains"
3. Add your custom domain
4. Update DNS records as instructed

---

## 🎨 Option 2: Netlify Deployment

**Best for**: Static sites with serverless functions
**Cost**: Free tier available
**Setup Time**: 10-15 minutes

### Step 1: Prepare for Netlify

1. **Create netlify.toml**:

```toml
[build]
  command = "npm run build"
  functions = "netlify/functions"
  publish = "public"

[build.environment]
  NODE_VERSION = "18"

[[redirects]]
  from = "/api/*"
  to = "/.netlify/functions/:splat"
  status = 200

[[redirects]]
  from = "/*"
  to = "/index.html"
  status = 200
```

2. **Create Netlify Functions**:

```javascript
// netlify/functions/api.js
const express = require('express');
const serverless = require('serverless-http');
const app = require('../../server-supabase');

module.exports.handler = serverless(app);
```

### Step 2: Deploy to Netlify

1. **Via Git (Recommended)**:
   - Push code to GitHub/GitLab
   - Connect repository in Netlify dashboard
   - Set build command: `npm run build`
   - Set publish directory: `public`

2. **Via Netlify CLI**:
   ```bash
   npm install -g netlify-cli
   netlify login
   netlify deploy --prod
   ```

3. **Set Environment Variables**:
   - Go to Site Settings → Environment Variables
   - Add your Supabase credentials

---

## 🚂 Option 3: Railway Deployment

**Best for**: Full-stack applications with databases
**Cost**: $5/month after free credits
**Setup Time**: 5 minutes

### Step 1: Prepare Railway Config

1. **Create railway.json**:

```json
{
  "$schema": "https://railway.app/railway.schema.json",
  "build": {
    "builder": "NIXPACKS"
  },
  "deploy": {
    "startCommand": "npm start",
    "healthcheckPath": "/api/health"
  }
}
```

### Step 2: Deploy to Railway

1. **Install Railway CLI**:
   ```bash
   npm install -g @railway/cli
   ```

2. **Login and Deploy**:
   ```bash
   railway login
   railway init
   railway up
   ```

3. **Set Environment Variables**:
   ```bash
   railway variables set SUPABASE_URL=your-url
   railway variables set SUPABASE_ANON_KEY=your-key
   railway variables set SUPABASE_SERVICE_ROLE_KEY=your-service-key
   ```

---

## 🎭 Option 4: Render Deployment

**Best for**: Full-stack apps with free tier
**Cost**: Free tier available
**Setup Time**: 10 minutes

### Step 1: Prepare for Render

1. **Create render.yaml**:

```yaml
services:
  - type: web
    name: tsp-clothing-brand
    env: node
    plan: free
    buildCommand: npm install
    startCommand: npm start
    envVars:
      - key: NODE_ENV
        value: production
      - key: SUPABASE_URL
        sync: false
      - key: SUPABASE_ANON_KEY
        sync: false
      - key: SUPABASE_SERVICE_ROLE_KEY
        sync: false
```

### Step 2: Deploy to Render

1. **Via Git**:
   - Push to GitHub
   - Connect repository in Render dashboard
   - Set build command: `npm install`
   - Set start command: `npm start`

2. **Set Environment Variables**:
   - Add Supabase credentials in Render dashboard

---

## 🔮 Option 5: Heroku Deployment

**Best for**: Traditional hosting with add-ons
**Cost**: $7/month minimum
**Setup Time**: 15 minutes

### Step 1: Prepare for Heroku

1. **Create Procfile**:

```
web: node server-supabase.js
```

2. **Update package.json**:

```json
{
  "engines": {
    "node": "18.x",
    "npm": "9.x"
  }
}
```

### Step 2: Deploy to Heroku

1. **Install Heroku CLI**:
   ```bash
   # Download from heroku.com/cli
   ```

2. **Deploy**:
   ```bash
   heroku login
   heroku create tsp-clothing-brand
   git push heroku main
   ```

3. **Set Environment Variables**:
   ```bash
   heroku config:set SUPABASE_URL=your-url
   heroku config:set SUPABASE_ANON_KEY=your-key
   heroku config:set SUPABASE_SERVICE_ROLE_KEY=your-service-key
   ```

---

## 📋 Pre-Deployment Checklist

### ✅ Code Preparation

- [ ] All environment variables are configured
- [ ] Supabase database schema is deployed
- [ ] Sample data is migrated
- [ ] Admin user is created
- [ ] All dependencies are in package.json
- [ ] Server starts without errors locally

### ✅ Supabase Configuration

- [ ] Project is created and active
- [ ] Database tables are created
- [ ] RLS policies are enabled
- [ ] API keys are copied
- [ ] Authentication settings are configured

### ✅ Domain & SSL

- [ ] Custom domain is purchased (optional)
- [ ] DNS records are configured
- [ ] SSL certificate is enabled (automatic on most platforms)

---

## 🔧 Production Configuration

### Environment Variables

Set these in your hosting platform:

```env
NODE_ENV=production
SUPABASE_URL=https://your-project-ref.supabase.co
SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
SUPABASE_SERVICE_ROLE_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
```

### Supabase Production Settings

1. **Authentication Settings**:
   - Site URL: `https://your-domain.com`
   - Redirect URLs: Add your production domain

2. **API Settings**:
   - Enable RLS on all tables
   - Review and test all policies

3. **Storage Settings** (if using):
   - Create `product-images` bucket
   - Set appropriate permissions

---

## 🚀 Quick Start Commands

### For Vercel:
```bash
npm install -g vercel
vercel login
vercel
# Set environment variables in dashboard
vercel --prod
```

### For Netlify:
```bash
npm install -g netlify-cli
netlify login
netlify init
netlify deploy --prod
```

### For Railway:
```bash
npm install -g @railway/cli
railway login
railway init
railway up
```

---

## 🔍 Testing Your Deployment

### 1. Basic Functionality Test

Visit your deployed URL and test:

- [ ] Homepage loads correctly
- [ ] Products page displays items
- [ ] Admin login works
- [ ] Admin dashboard is accessible
- [ ] API endpoints respond correctly

### 2. API Health Check

Visit: `https://your-domain.com/api/health`

Should return:
```json
{
  "success": true,
  "message": "TSP API is running",
  "timestamp": "2024-02-05T...",
  "supabase": {
    "url": "configured",
    "connected": true
  }
}
```

### 3. Admin Access Test

1. Go to: `https://your-domain.com`
2. Click "Login"
3. Use: `admin` / `admin123`
4. Should redirect to admin dashboard

---

## 🛠️ Troubleshooting Common Issues

### "Module not found" errors
- Ensure all dependencies are in `package.json`
- Run `npm install` locally to verify

### "Environment variable not found"
- Check environment variables are set in hosting platform
- Verify variable names match exactly

### "Database connection failed"
- Verify Supabase URL and keys are correct
- Check Supabase project is active
- Test connection locally first

### "CORS errors"
- Add your domain to Supabase Auth settings
- Check CORS configuration in server

### "404 on refresh"
- Configure proper redirects for SPA routing
- Check hosting platform's SPA settings

---

## 💰 Cost Comparison

| Platform | Free Tier | Paid Plans | Best For |
|----------|-----------|------------|----------|
| **Vercel** | 100GB bandwidth | $20/month | Full-stack apps |
| **Netlify** | 100GB bandwidth | $19/month | Static + functions |
| **Railway** | $5 credit | $5/month | Simple deployment |
| **Render** | 750 hours/month | $7/month | Free hosting |
| **Heroku** | None | $7/month | Enterprise features |

---

## 🎉 You're Live!

Once deployed, your TSP Clothing Brand website will be accessible worldwide with:

- ✅ Professional domain
- ✅ SSL certificate
- ✅ Global CDN
- ✅ Automatic scaling
- ✅ 99.9% uptime
- ✅ Admin dashboard
- ✅ Real-time updates
- ✅ Secure authentication

**Recommended**: Start with **Vercel** for the best balance of features, performance, and ease of use.

Happy deploying! 🚀