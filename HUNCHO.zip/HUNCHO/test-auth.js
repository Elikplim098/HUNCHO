// Test authentication endpoints
const fetch = (...args) => import('node-fetch').then(({default: fetch}) => fetch(...args));

const BASE_URL = 'http://localhost:3001';

async function testAuth() {
    console.log('🧪 Testing Authentication Endpoints');
    console.log('===================================');
    
    try {
        // Test 1: Health check
        console.log('\n1. Testing health endpoint...');
        const healthResponse = await fetch(`${BASE_URL}/api/health`);
        const healthData = await healthResponse.json();
        console.log('✅ Health check:', healthData);
        
        // Test 2: User signup
        console.log('\n2. Testing user signup...');
        const signupResponse = await fetch(`${BASE_URL}/api/auth/signup`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                name: 'John Doe',
                email: 'john@example.com',
                password: 'password123'
            })
        });
        
        const signupData = await signupResponse.json();
        console.log('✅ Signup response:', signupData);
        
        if (!signupData.success) {
            throw new Error('Signup failed: ' + signupData.message);
        }
        
        // Test 3: User login
        console.log('\n3. Testing user login...');
        const loginResponse = await fetch(`${BASE_URL}/api/auth/login`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                email: 'john@example.com',
                password: 'password123'
            })
        });
        
        const loginData = await loginResponse.json();
        console.log('✅ Login response:', loginData);
        
        if (!loginData.success) {
            throw new Error('Login failed: ' + loginData.message);
        }
        
        // Test 4: Try login with wrong password
        console.log('\n4. Testing login with wrong password...');
        const wrongLoginResponse = await fetch(`${BASE_URL}/api/auth/login`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                email: 'john@example.com',
                password: 'wrongpassword'
            })
        });
        
        const wrongLoginData = await wrongLoginResponse.json();
        console.log('✅ Wrong password response:', wrongLoginData);
        
        // Test 5: Admin login
        console.log('\n5. Testing admin login...');
        const adminResponse = await fetch(`${BASE_URL}/api/auth/admin-login`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                username: 'admin',
                password: 'admin123'
            })
        });
        
        const adminData = await adminResponse.json();
        console.log('✅ Admin login response:', adminData);
        
        console.log('\n🎉 All authentication tests passed!');
        
    } catch (error) {
        console.error('❌ Test failed:', error.message);
    }
}

// Run tests
testAuth();