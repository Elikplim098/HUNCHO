const express = require('express');
const cors = require('cors');
const path = require('path');
const { createClient } = require('@supabase/supabase-js');
const userStorage = require('./user-storage');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

// Initialize Supabase client
const supabaseUrl = process.env.SUPABASE_URL;
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY; // Use service role key for server-side operations
const supabaseAnonKey = process.env.SUPABASE_ANON_KEY;

let supabaseAdmin = null;
let supabase = null;

// Only initialize Supabase if credentials are provided
if (supabaseUrl && supabaseUrl !== 'YOUR_SUPABASE_URL' && supabaseServiceKey && supabaseAnonKey) {
    try {
        supabaseAdmin = createClient(supabaseUrl, supabaseServiceKey); // For admin operations
        supabase = createClient(supabaseUrl, supabaseAnonKey); // For public operations
        console.log('✅ Supabase initialized successfully');
    } catch (error) {
        console.error('❌ Supabase initialization failed:', error.message);
        console.log('📝 Falling back to local user storage');
    }
} else {
    console.log('⚠️  Supabase not configured, using local user storage');
    console.log('   To use Supabase, update your .env file with:');
    console.log('   - SUPABASE_URL');
    console.log('   - SUPABASE_ANON_KEY');
    console.log('   - SUPABASE_SERVICE_ROLE_KEY');
}

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'));

// Add Supabase client to request object
app.use((req, res, next) => {
    req.supabase = supabase;
    req.supabaseAdmin = supabaseAdmin;
    next();
});

// Authentication middleware
const authenticateUser = async (req, res, next) => {
    const token = req.headers.authorization?.replace('Bearer ', '');
    
    if (!token) {
        return res.status(401).json({ success: false, message: 'No token provided' });
    }
    
    try {
        // Check if it's a local session token
        if (token.startsWith('local_session_')) {
            const userId = token.split('_').pop();
            const user = userStorage.getUserById(userId);
            
            if (!user) {
                return res.status(401).json({ success: false, message: 'Invalid token' });
            }
            
            req.user = user;
            next();
            return;
        }
        
        // Try Supabase token validation
        if (supabaseUrl && supabaseServiceKey) {
            const { data: { user }, error } = await supabase.auth.getUser(token);
            
            if (error || !user) {
                return res.status(401).json({ success: false, message: 'Invalid token' });
            }
            
            req.user = user;
            next();
            return;
        }
        
        // If no authentication method available
        return res.status(401).json({ success: false, message: 'Authentication not available' });
        
    } catch (error) {
        console.error('Authentication error:', error);
        return res.status(401).json({ success: false, message: 'Authentication failed' });
    }
};

// Admin middleware
const requireAdmin = async (req, res, next) => {
    if (!req.user) {
        return res.status(401).json({ success: false, message: 'Authentication required' });
    }
    
    try {
        // Check if user is from local storage
        if (req.user.id && req.user.id.startsWith('local_')) {
            const user = userStorage.getUserById(req.user.id);
            if (user && user.role === 'admin') {
                next();
                return;
            }
        }
        
        // Check Supabase user role
        if (supabaseUrl && supabaseServiceKey) {
            const { data: userData, error } = await supabaseAdmin
                .from('users')
                .select('role')
                .eq('id', req.user.id)
                .single();
            
            if (!error && userData?.role === 'admin') {
                next();
                return;
            }
        }
        
        return res.status(403).json({ success: false, message: 'Admin access required' });
        
    } catch (error) {
        console.error('Admin check error:', error);
        return res.status(500).json({ success: false, message: 'Authorization check failed' });
    }
};

// Products API Routes
app.get('/api/products', async (req, res) => {
    try {
        const { category, featured, limit } = req.query;
        
        let query = supabase
            .from('products')
            .select('*')
            .eq('active', true)
            .order('created_at', { ascending: false });
        
        if (category) {
            query = query.eq('category', category);
        }
        
        if (featured === 'true') {
            query = query.eq('featured', true);
        }
        
        if (limit) {
            query = query.limit(parseInt(limit));
        }
        
        const { data: products, error } = await query;
        
        if (error) {
            throw error;
        }
        
        res.json({ success: true, products });
    } catch (error) {
        console.error('Error fetching products:', error);
        res.status(500).json({ success: false, message: 'Failed to fetch products' });
    }
});

app.get('/api/products/featured', async (req, res) => {
    try {
        const { data: products, error } = await supabase
            .from('products')
            .select('*')
            .eq('featured', true)
            .eq('active', true)
            .limit(8)
            .order('created_at', { ascending: false });
        
        if (error) {
            throw error;
        }
        
        res.json({ success: true, products });
    } catch (error) {
        console.error('Error fetching featured products:', error);
        res.status(500).json({ success: false, message: 'Failed to fetch featured products' });
    }
});

app.get('/api/products/:id', async (req, res) => {
    try {
        const { data: product, error } = await supabase
            .from('products')
            .select('*')
            .eq('id', req.params.id)
            .eq('active', true)
            .single();
        
        if (error) {
            if (error.code === 'PGRST116') {
                return res.status(404).json({ success: false, message: 'Product not found' });
            }
            throw error;
        }
        
        res.json({ success: true, product });
    } catch (error) {
        console.error('Error fetching product:', error);
        res.status(500).json({ success: false, message: 'Failed to fetch product' });
    }
});

// Admin Products Routes
app.post('/api/admin/products', async (req, res) => {
    try {
        // Check for admin authentication
        const authHeader = req.headers.authorization;
        
        if (!authHeader || !authHeader.startsWith('Bearer ')) {
            return res.status(401).json({ success: false, message: 'Admin authentication required' });
        }
        
        const token = authHeader.replace('Bearer ', '');
        
        // Check if it's an admin token
        if (!token.startsWith('admin-token-')) {
            return res.status(401).json({ success: false, message: 'Invalid admin token' });
        }
        
        const productData = {
            ...req.body,
            id: 'product_' + Date.now(),
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString()
        };
        
        // Try Supabase first
        if (supabaseAdmin) {
            try {
                const { data: product, error } = await supabaseAdmin
                    .from('products')
                    .insert([productData])
                    .select()
                    .single();
                
                if (error) {
                    throw error;
                }
                
                return res.json({ success: true, product });
            } catch (supabaseError) {
                console.log('Supabase product creation failed, using fallback:', supabaseError.message);
            }
        }
        
        // Fallback - return success with the product data
        res.json({ success: true, product: productData, storage: 'local' });
        
    } catch (error) {
        console.error('Error creating product:', error);
        res.status(500).json({ success: false, message: 'Failed to create product' });
    }
});

app.put('/api/admin/products/:id', async (req, res) => {
    try {
        // Check for admin authentication
        const authHeader = req.headers.authorization;
        
        if (!authHeader || !authHeader.startsWith('Bearer ')) {
            return res.status(401).json({ success: false, message: 'Admin authentication required' });
        }
        
        const token = authHeader.replace('Bearer ', '');
        
        if (!token.startsWith('admin-token-')) {
            return res.status(401).json({ success: false, message: 'Invalid admin token' });
        }
        
        const updates = {
            ...req.body,
            updated_at: new Date().toISOString()
        };
        
        // Try Supabase first
        if (supabaseAdmin) {
            try {
                const { data: product, error } = await supabaseAdmin
                    .from('products')
                    .update(updates)
                    .eq('id', req.params.id)
                    .select()
                    .single();
                
                if (error) {
                    throw error;
                }
                
                return res.json({ success: true, product });
            } catch (supabaseError) {
                console.log('Supabase product update failed:', supabaseError.message);
            }
        }
        
        // Fallback response
        res.json({ success: true, product: { id: req.params.id, ...updates }, storage: 'local' });
        
    } catch (error) {
        console.error('Error updating product:', error);
        res.status(500).json({ success: false, message: 'Failed to update product' });
    }
});

app.delete('/api/admin/products/:id', async (req, res) => {
    try {
        // Check for admin authentication
        const authHeader = req.headers.authorization;
        
        if (!authHeader || !authHeader.startsWith('Bearer ')) {
            return res.status(401).json({ success: false, message: 'Admin authentication required' });
        }
        
        const token = authHeader.replace('Bearer ', '');
        
        if (!token.startsWith('admin-token-')) {
            return res.status(401).json({ success: false, message: 'Invalid admin token' });
        }
        
        // Try Supabase first
        if (supabaseAdmin) {
            try {
                const { error } = await supabaseAdmin
                    .from('products')
                    .delete()
                    .eq('id', req.params.id);
                
                if (error) {
                    throw error;
                }
                
                return res.json({ success: true, message: 'Product deleted successfully' });
            } catch (supabaseError) {
                console.log('Supabase product deletion failed:', supabaseError.message);
            }
        }
        
        // Fallback response
        res.json({ success: true, message: 'Product deleted successfully', storage: 'local' });
        
    } catch (error) {
        console.error('Error deleting product:', error);
        res.status(500).json({ success: false, message: 'Failed to delete product' });
    }
});

// Authentication Routes
app.post('/api/auth/signup', async (req, res) => {
    try {
        const { email, password, name } = req.body;
        
        // Validate input
        if (!email || !password) {
            return res.status(400).json({ success: false, message: 'Email and password are required' });
        }
        
        if (password.length < 6) {
            return res.status(400).json({ success: false, message: 'Password must be at least 6 characters long' });
        }
        
        // Try Supabase authentication first
        if (supabaseUrl && supabaseServiceKey) {
            try {
                const { data: authData, error: authError } = await supabase.auth.signUp({
                    email,
                    password,
                });
                
                if (authError) {
                    throw authError;
                }
                
                // Create user profile in Supabase
                if (authData.user) {
                    const { error: profileError } = await supabaseAdmin
                        .from('users')
                        .insert([{
                            id: authData.user.id,
                            email: authData.user.email,
                            name: name || null,
                            role: 'customer'
                        }]);
                    
                    if (profileError) {
                        console.error('Error creating user profile:', profileError);
                    }
                }
                
                res.json({ 
                    success: true, 
                    user: authData.user,
                    session: authData.session,
                    message: 'User created successfully. Please check your email to verify your account.' 
                });
                return;
                
            } catch (supabaseError) {
                console.log('Supabase signup failed, using local storage fallback:', supabaseError.message);
            }
        }
        
        // Fallback to local file storage
        try {
            const newUser = await userStorage.createUser(email, password, name);
            
            // Create a session token for the new user
            const sessionToken = 'local_session_' + Date.now() + '_' + newUser.id;
            
            res.json({
                success: true,
                user: newUser,
                session: {
                    access_token: sessionToken,
                    user: newUser
                },
                message: 'User created successfully'
            });
            
        } catch (storageError) {
            res.status(400).json({ success: false, message: storageError.message });
        }
        
    } catch (error) {
        console.error('Signup error:', error);
        res.status(500).json({ success: false, message: 'Internal server error' });
    }
});

app.post('/api/auth/login', async (req, res) => {
    try {
        const { email, password } = req.body;
        
        // Validate input
        if (!email || !password) {
            return res.status(400).json({ success: false, message: 'Email and password are required' });
        }
        
        // Try Supabase authentication first
        if (supabaseUrl && supabaseServiceKey) {
            try {
                const { data, error } = await supabase.auth.signInWithPassword({
                    email,
                    password,
                });
                
                if (error) {
                    throw error;
                }
                
                // Get user profile from Supabase
                const { data: userProfile, error: profileError } = await supabaseAdmin
                    .from('users')
                    .select('*')
                    .eq('id', data.user.id)
                    .single();
                
                if (profileError) {
                    console.error('Error fetching user profile:', profileError);
                }
                
                res.json({ 
                    success: true, 
                    user: data.user,
                    profile: userProfile,
                    session: data.session,
                    message: 'Login successful' 
                });
                return;
                
            } catch (supabaseError) {
                console.log('Supabase login failed, trying local storage fallback:', supabaseError.message);
            }
        }
        
        // Fallback to local file storage
        try {
            const user = await userStorage.authenticateUser(email, password);
            
            // Create session token
            const sessionToken = 'local_session_' + Date.now() + '_' + user.id;
            
            res.json({
                success: true,
                user: user,
                session: {
                    access_token: sessionToken,
                    user: user
                },
                message: 'Login successful'
            });
            
        } catch (storageError) {
            res.status(401).json({ success: false, message: storageError.message });
        }
        
    } catch (error) {
        console.error('Login error:', error);
        res.status(500).json({ success: false, message: 'Internal server error' });
    }
});

app.post('/api/auth/logout', async (req, res) => {
    try {
        // Try Supabase logout first
        if (supabaseUrl && supabaseServiceKey) {
            const { error } = await supabase.auth.signOut();
            if (error) {
                console.log('Supabase logout error:', error.message);
            }
        }
        
        res.json({ success: true, message: 'Logout successful' });
    } catch (error) {
        console.error('Logout error:', error);
        res.status(400).json({ success: false, message: error.message });
    }
});

// Get user profile
app.get('/api/auth/profile', authenticateUser, async (req, res) => {
    try {
        // If user is from Supabase
        if (req.user.id && !req.user.id.startsWith('local_')) {
            const { data: userProfile, error } = await supabaseAdmin
                .from('users')
                .select('*')
                .eq('id', req.user.id)
                .single();
            
            if (error) {
                console.error('Error fetching Supabase user profile:', error);
            } else {
                return res.json({ success: true, user: userProfile });
            }
        }
        
        // If user is from local storage
        if (req.user.id && req.user.id.startsWith('local_')) {
            const user = userStorage.getUserById(req.user.id);
            if (user) {
                return res.json({ success: true, user });
            }
        }
        
        // Return the user from the token
        res.json({ success: true, user: req.user });
        
    } catch (error) {
        console.error('Profile fetch error:', error);
        res.status(500).json({ success: false, message: 'Failed to fetch profile' });
    }
});

// Admin login route (simplified for demo)
app.post('/api/auth/admin-login', async (req, res) => {
    try {
        const { username, password } = req.body;
        
        // Simple admin check - in production, use proper authentication
        if (username === 'admin' && password === 'admin123') {
            // Create a simple admin session token
            const adminToken = 'admin-token-' + Date.now();
            
            res.json({
                success: true,
                user: {
                    id: 'admin',
                    username: 'admin',
                    name: 'Administrator',
                    role: 'admin',
                    isAdmin: true
                },
                token: adminToken,
                message: 'Admin login successful'
            });
        } else {
            res.status(401).json({ success: false, message: 'Invalid admin credentials' });
        }
    } catch (error) {
        console.error('Admin login error:', error);
        res.status(500).json({ success: false, message: 'Admin login failed' });
    }
});

// Orders API Routes
app.get('/api/orders', authenticateUser, async (req, res) => {
    try {
        const { data: orders, error } = await supabase
            .from('orders')
            .select(`
                *,
                order_items (
                    *,
                    products (*)
                )
            `)
            .eq('user_id', req.user.id)
            .order('created_at', { ascending: false });
        
        if (error) {
            throw error;
        }
        
        res.json({ success: true, orders });
    } catch (error) {
        console.error('Error fetching orders:', error);
        res.status(500).json({ success: false, message: 'Failed to fetch orders' });
    }
});

app.post('/api/orders', authenticateUser, async (req, res) => {
    try {
        const { items, shipping_address, total_amount, subtotal, tax_amount, shipping_amount } = req.body;
        
        // Create order
        const { data: order, error: orderError } = await supabaseAdmin
            .from('orders')
            .insert([{
                user_id: req.user.id,
                total_amount,
                subtotal,
                tax_amount: tax_amount || 0,
                shipping_amount: shipping_amount || 0,
                shipping_address,
                status: 'pending',
                payment_status: 'pending'
            }])
            .select()
            .single();
        
        if (orderError) {
            throw orderError;
        }
        
        // Create order items
        const orderItems = items.map(item => ({
            order_id: order.id,
            product_id: item.product_id,
            product_name: item.name,
            product_image: item.image,
            size: item.size,
            color: item.color,
            quantity: item.quantity,
            unit_price: item.price,
            total_price: item.price * item.quantity
        }));
        
        const { error: itemsError } = await supabaseAdmin
            .from('order_items')
            .insert(orderItems);
        
        if (itemsError) {
            throw itemsError;
        }
        
        res.json({ success: true, order });
    } catch (error) {
        console.error('Error creating order:', error);
        res.status(500).json({ success: false, message: 'Failed to create order' });
    }
});

// Newsletter subscription
app.post('/api/newsletter/subscribe', async (req, res) => {
    try {
        const { email, name } = req.body;
        
        const { data, error } = await supabaseAdmin
            .from('newsletter_subscribers')
            .insert([{ email, name }])
            .select()
            .single();
        
        if (error) {
            if (error.code === '23505') { // Unique constraint violation
                return res.status(400).json({ success: false, message: 'Email already subscribed' });
            }
            throw error;
        }
        
        res.json({ success: true, message: 'Successfully subscribed to newsletter' });
    } catch (error) {
        console.error('Newsletter subscription error:', error);
        res.status(500).json({ success: false, message: 'Failed to subscribe' });
    }
});

// Health check endpoint
app.get('/api/health', (req, res) => {
    res.json({ 
        success: true, 
        message: 'TSP API is running',
        timestamp: new Date().toISOString(),
        supabase: {
            url: supabaseUrl && supabaseUrl !== 'YOUR_SUPABASE_URL' ? 'configured' : 'not configured',
            connected: supabaseAdmin !== null
        },
        userStorage: {
            type: supabaseAdmin ? 'Supabase + Local Fallback' : 'Local File Storage',
            available: true
        }
    });
});

// Serve static files
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// 404 handler
app.use('*', (req, res) => {
    res.status(404).json({ success: false, message: 'Route not found' });
});

// Error handler
app.use((error, req, res, next) => {
    console.error('Server error:', error);
    res.status(500).json({ success: false, message: 'Internal server error' });
});

app.listen(PORT, () => {
    console.log(`🚀 TSP Server running on port ${PORT}`);
    console.log(`📊 Supabase URL: ${supabaseUrl ? 'configured' : 'missing'}`);
    console.log(`🔑 Supabase Keys: ${supabaseServiceKey && supabaseAnonKey ? 'configured' : 'missing'}`);
});

module.exports = app;