#!/usr/bin/env node

const fs = require('fs');
const readline = require('readline');

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

console.log('🏪 TSP Clothing Brand - Setup Wizard');
console.log('====================================');
console.log('This wizard will help you configure your Supabase credentials.\n');

function askQuestion(question) {
    return new Promise((resolve) => {
        rl.question(question, (answer) => {
            resolve(answer);
        });
    });
}

async function setupSupabase() {
    console.log('📊 Supabase Configuration');
    console.log('-------------------------');
    console.log('You can find these values in your Supabase project dashboard:');
    console.log('Settings → API\n');
    
    const supabaseUrl = await askQuestion('🔗 Enter your Supabase Project URL: ');
    const supabaseAnonKey = await askQuestion('🔑 Enter your Supabase Anon Key: ');
    const supabaseServiceKey = await askQuestion('🔐 Enter your Supabase Service Role Key: ');
    
    // Update .env file
    const envContent = `PORT=3000
NODE_ENV=development

# MongoDB (Legacy - can be removed when fully migrated to Supabase)
# MONGODB_URI=mongodb://localhost:27017/thestreetpays
# JWT_SECRET=your_jwt_secret_here

# Supabase Configuration
SUPABASE_URL=${supabaseUrl}
SUPABASE_ANON_KEY=${supabaseAnonKey}
SUPABASE_SERVICE_ROLE_KEY=${supabaseServiceKey}
`;
    
    fs.writeFileSync('.env', envContent);
    console.log('\n✅ Environment variables saved to .env file');
    
    return { supabaseUrl, supabaseAnonKey, supabaseServiceKey };
}

async function setupDatabase() {
    console.log('\n📊 Database Setup');
    console.log('-----------------');
    console.log('Next, you need to set up your database schema in Supabase:');
    console.log('1. Go to your Supabase dashboard');
    console.log('2. Navigate to SQL Editor');
    console.log('3. Copy the contents of database-schema.sql');
    console.log('4. Paste and run the SQL in the editor');
    
    const dbSetup = await askQuestion('\nHave you set up the database schema? (y/n): ');
    
    if (dbSetup.toLowerCase() !== 'y') {
        console.log('\n⚠️  Please set up the database schema before continuing.');
        console.log('   The schema file is: database-schema.sql');
        return false;
    }
    
    return true;
}

async function choosePlatform() {
    console.log('\n🚀 Deployment Platform');
    console.log('----------------------');
    console.log('Choose your preferred hosting platform:');
    console.log('1. Vercel (Recommended - Easy setup, great performance)');
    console.log('2. Netlify (Good for static sites with functions)');
    console.log('3. Railway (Simple full-stack hosting)');
    console.log('4. Skip deployment setup');
    
    const choice = await askQuestion('\nEnter your choice (1-4): ');
    
    const platforms = {
        '1': 'vercel',
        '2': 'netlify',
        '3': 'railway',
        '4': 'skip'
    };
    
    return platforms[choice] || 'skip';
}

async function showNextSteps(platform, credentials) {
    console.log('\n🎉 Setup Complete!');
    console.log('==================');
    
    console.log('\n📝 What was configured:');
    console.log('✅ Environment variables (.env file)');
    console.log('✅ Supabase credentials');
    console.log('✅ Deployment configuration files');
    
    console.log('\n🚀 Next Steps:');
    
    if (platform !== 'skip') {
        console.log(`\n1. Deploy to ${platform.toUpperCase()}:`);
        console.log(`   node deploy.js ${platform}`);
        console.log('\n2. Set environment variables in your hosting platform dashboard');
        console.log('3. Test your deployed website');
    } else {
        console.log('\n1. Test locally:');
        console.log('   npm run start:supabase');
        console.log('\n2. When ready to deploy:');
        console.log('   node deploy.js vercel');
        console.log('   (or netlify, railway)');
    }
    
    console.log('\n🔧 Admin Access:');
    console.log('   Username: admin');
    console.log('   Password: admin123');
    
    console.log('\n📚 Documentation:');
    console.log('   Setup Guide: SUPABASE_SETUP_GUIDE.md');
    console.log('   Deployment Guide: DEPLOYMENT_GUIDE.md');
    
    console.log('\n💡 Helpful Commands:');
    console.log('   npm run dev:supabase    - Start development server');
    console.log('   npm run migrate         - Populate database with sample data');
    console.log('   node deploy.js <platform> - Deploy to hosting platform');
    
    console.log('\n🌐 Your Supabase Project:');
    console.log(`   Dashboard: ${credentials.supabaseUrl.replace('/rest/v1', '')}`);
    
    console.log('\n🎊 Happy coding!');
}

async function main() {
    try {
        // Setup Supabase credentials
        const credentials = await setupSupabase();
        
        // Setup database
        const dbReady = await setupDatabase();
        
        if (!dbReady) {
            console.log('\n❌ Setup incomplete. Please set up the database and run setup again.');
            rl.close();
            return;
        }
        
        // Choose deployment platform
        const platform = await choosePlatform();
        
        // Show next steps
        await showNextSteps(platform, credentials);
        
        rl.close();
        
    } catch (error) {
        console.error('\n❌ Setup failed:', error.message);
        rl.close();
        process.exit(1);
    }
}

// Run setup
main();