#!/usr/bin/env node

const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');

console.log('🚀 TSP Clothing Brand - Deployment Helper');
console.log('=========================================');

// Check if we're in a git repository
function checkGitRepo() {
    try {
        execSync('git status', { stdio: 'ignore' });
        return true;
    } catch (error) {
        return false;
    }
}

// Initialize git repository if needed
function initGit() {
    if (!checkGitRepo()) {
        console.log('📁 Initializing Git repository...');
        execSync('git init');
        execSync('git add .');
        execSync('git commit -m "Initial commit - TSP Clothing Brand"');
        console.log('✅ Git repository initialized');
    } else {
        console.log('✅ Git repository already exists');
    }
}

// Check if .env file exists and has Supabase config
function checkSupabaseConfig() {
    if (!fs.existsSync('.env')) {
        console.log('❌ .env file not found');
        console.log('   Please create .env file with your Supabase credentials');
        return false;
    }
    
    const envContent = fs.readFileSync('.env', 'utf8');
    const hasSupabaseUrl = envContent.includes('SUPABASE_URL=') && !envContent.includes('YOUR_SUPABASE_URL');
    const hasSupabaseKey = envContent.includes('SUPABASE_ANON_KEY=') && !envContent.includes('YOUR_SUPABASE_ANON_KEY');
    
    if (!hasSupabaseUrl || !hasSupabaseKey) {
        console.log('⚠️  Supabase configuration incomplete in .env file');
        console.log('   Please update your Supabase credentials before deploying');
        return false;
    }
    
    console.log('✅ Supabase configuration found');
    return true;
}

// Deploy to Vercel
function deployToVercel() {
    console.log('\n🔵 Deploying to Vercel...');
    
    try {
        // Check if vercel is installed
        execSync('vercel --version', { stdio: 'ignore' });
    } catch (error) {
        console.log('📦 Installing Vercel CLI...');
        execSync('npm install -g vercel');
    }
    
    try {
        console.log('🚀 Starting Vercel deployment...');
        execSync('vercel --prod', { stdio: 'inherit' });
        console.log('✅ Deployed to Vercel successfully!');
        return true;
    } catch (error) {
        console.log('❌ Vercel deployment failed');
        console.log('   Please run: vercel login');
        console.log('   Then try again: node deploy.js vercel');
        return false;
    }
}

// Deploy to Netlify
function deployToNetlify() {
    console.log('\n🟠 Deploying to Netlify...');
    
    try {
        // Check if netlify-cli is installed
        execSync('netlify --version', { stdio: 'ignore' });
    } catch (error) {
        console.log('📦 Installing Netlify CLI...');
        execSync('npm install -g netlify-cli');
    }
    
    try {
        console.log('🚀 Starting Netlify deployment...');
        execSync('netlify deploy --prod', { stdio: 'inherit' });
        console.log('✅ Deployed to Netlify successfully!');
        return true;
    } catch (error) {
        console.log('❌ Netlify deployment failed');
        console.log('   Please run: netlify login');
        console.log('   Then try again: node deploy.js netlify');
        return false;
    }
}

// Deploy to Railway
function deployToRailway() {
    console.log('\n🟣 Deploying to Railway...');
    
    try {
        // Check if railway is installed
        execSync('railway --version', { stdio: 'ignore' });
    } catch (error) {
        console.log('📦 Installing Railway CLI...');
        execSync('npm install -g @railway/cli');
    }
    
    try {
        console.log('🚀 Starting Railway deployment...');
        execSync('railway up', { stdio: 'inherit' });
        console.log('✅ Deployed to Railway successfully!');
        return true;
    } catch (error) {
        console.log('❌ Railway deployment failed');
        console.log('   Please run: railway login');
        console.log('   Then try again: node deploy.js railway');
        return false;
    }
}

// Main deployment function
function deploy(platform) {
    console.log(`\n🎯 Target Platform: ${platform.toUpperCase()}`);
    
    // Pre-deployment checks
    console.log('\n📋 Pre-deployment checks...');
    
    initGit();
    
    if (!checkSupabaseConfig()) {
        console.log('\n❌ Deployment aborted due to missing Supabase configuration');
        console.log('\n📝 Next steps:');
        console.log('1. Create a Supabase project at https://supabase.com');
        console.log('2. Update your .env file with the project credentials');
        console.log('3. Run the database schema in Supabase SQL Editor');
        console.log('4. Try deploying again');
        process.exit(1);
    }
    
    // Install dependencies
    console.log('📦 Installing dependencies...');
    execSync('npm install', { stdio: 'inherit' });
    
    // Deploy based on platform
    let success = false;
    
    switch (platform.toLowerCase()) {
        case 'vercel':
            success = deployToVercel();
            break;
        case 'netlify':
            success = deployToNetlify();
            break;
        case 'railway':
            success = deployToRailway();
            break;
        default:
            console.log('❌ Unknown platform. Supported: vercel, netlify, railway');
            process.exit(1);
    }
    
    if (success) {
        console.log('\n🎉 Deployment completed successfully!');
        console.log('\n📝 Next steps:');
        console.log('1. Test your deployed website');
        console.log('2. Set up your custom domain (optional)');
        console.log('3. Configure environment variables in the platform dashboard');
        console.log('4. Test admin login functionality');
    } else {
        console.log('\n❌ Deployment failed. Please check the errors above.');
    }
}

// Show help
function showHelp() {
    console.log('\n📖 Usage:');
    console.log('  node deploy.js <platform>');
    console.log('\n🌐 Supported platforms:');
    console.log('  vercel   - Deploy to Vercel (recommended)');
    console.log('  netlify  - Deploy to Netlify');
    console.log('  railway  - Deploy to Railway');
    console.log('\n💡 Examples:');
    console.log('  node deploy.js vercel');
    console.log('  node deploy.js netlify');
    console.log('  node deploy.js railway');
}

// Parse command line arguments
const args = process.argv.slice(2);

if (args.length === 0) {
    console.log('❓ No platform specified');
    showHelp();
    process.exit(1);
}

const platform = args[0];

if (platform === 'help' || platform === '--help' || platform === '-h') {
    showHelp();
    process.exit(0);
}

// Start deployment
deploy(platform);