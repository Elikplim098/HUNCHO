// The Street Pays - Main JavaScript

// Global variables
let cart = [];
let currentUser = null;

// DOM Content Loaded
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
});

// Initialize the application
function initializeApp() {
    // Load cart from localStorage
    loadCart();
    
    // Initialize event listeners
    initializeEventListeners();
    
    // Load featured products
    loadFeaturedProducts();
    
    // Check authentication status
    checkAuthStatus();
}

// Initialize event listeners
function initializeEventListeners() {
    // Mobile menu toggle
    const hamburger = document.getElementById('hamburger');
    const navMenu = document.getElementById('navMenu');
    
    if (hamburger && navMenu) {
        hamburger.addEventListener('click', function() {
            navMenu.classList.toggle('active');
            hamburger.classList.toggle('active');
        });
    }
    
    // Cart functionality
    const cartLink = document.getElementById('cartLink');
    if (cartLink) {
        cartLink.addEventListener('click', function(e) {
            e.preventDefault();
            showCart();
        });
    }
    
    // Add to cart buttons
    document.addEventListener('click', function(e) {
        if (e.target.classList.contains('add-to-cart-btn') || 
            e.target.closest('.add-to-cart-btn')) {
            e.preventDefault();
            const productCard = e.target.closest('.product-card');
            if (productCard) {
                addToCart(productCard);
            }
        }
    });
    
    // Newsletter form
    const newsletterForm = document.getElementById('newsletterForm');
    if (newsletterForm) {
        newsletterForm.addEventListener('submit', function(e) {
            e.preventDefault();
            handleNewsletterSignup(this);
        });
    }
    
    // Login button - handled by setupAdminAuth()
    // const loginBtn = document.getElementById('loginBtn');
    // if (loginBtn) {
    //     loginBtn.addEventListener('click', function() {
    //         showLoginModal();
    //     });
    // }
    
    // Admin button - handled by setupAdminAuth()
    // const adminBtn = document.getElementById('adminBtn');
    // if (adminBtn) {
    //     adminBtn.addEventListener('click', function() {
    //         showAdminDashboard();
    //     });
    // }
}

// Cart functionality
function loadCart() {
    const savedCart = localStorage.getItem('tsp_cart');
    if (savedCart) {
        cart = JSON.parse(savedCart);
        updateCartBadge();
    }
}

function saveCart() {
    localStorage.setItem('tsp_cart', JSON.stringify(cart));
    updateCartBadge();
}

function addToCart(productCard) {
    const product = {
        id: Date.now(),
        name: productCard.querySelector('.product-title').textContent,
        price: productCard.querySelector('.product-price').textContent,
        image: productCard.querySelector('.product-image img').src,
        quantity: 1
    };
    
    cart.push(product);
    saveCart();
    
    // Show success message
    showNotification('Product added to cart!', 'success');
}

function updateCartBadge() {
    const cartBadge = document.getElementById('cartBadge');
    if (cartBadge) {
        cartBadge.textContent = cart.length;
    }
}

function showCart() {
    // Create cart modal
    const cartModal = document.createElement('div');
    cartModal.className = 'modal';
    cartModal.innerHTML = `
        <div class="modal-content">
            <span class="close">&times;</span>
            <h2>Shopping Cart</h2>
            <div class="cart-items">
                ${cart.length === 0 ? '<p>Your cart is empty</p>' : cart.map(item => `
                    <div class="cart-item">
                        <img src="${item.image}" alt="${item.name}" style="width: 50px; height: 50px; object-fit: cover;">
                        <div class="cart-item-info">
                            <h4>${item.name}</h4>
                            <p>${item.price}</p>
                        </div>
                        <button class="remove-item" data-id="${item.id}">Remove</button>
                    </div>
                `).join('')}
            </div>
            ${cart.length > 0 ? '<button class="btn-primary checkout-btn">Checkout</button>' : ''}
        </div>
    `;
    
    document.body.appendChild(cartModal);
    cartModal.style.display = 'block';
    
    // Close modal functionality
    const closeBtn = cartModal.querySelector('.close');
    closeBtn.addEventListener('click', function() {
        document.body.removeChild(cartModal);
    });
    
    // Remove item functionality
    cartModal.addEventListener('click', function(e) {
        if (e.target.classList.contains('remove-item')) {
            const itemId = parseInt(e.target.dataset.id);
            cart = cart.filter(item => item.id !== itemId);
            saveCart();
            document.body.removeChild(cartModal);
            showCart(); // Refresh cart display
        }
    });
    
    // Checkout functionality
    const checkoutBtn = cartModal.querySelector('.checkout-btn');
    if (checkoutBtn) {
        checkoutBtn.addEventListener('click', function() {
            showNotification('Checkout functionality coming soon!', 'info');
        });
    }
}

// Load featured products
async function loadFeaturedProducts() {
    try {
        const response = await fetch('/api/products/featured');
        const data = await response.json();
        
        if (data.success && data.products) {
            displayFeaturedProducts(data.products);
        }
    } catch (error) {
        console.log('Using default products');
        // Use default products if API is not available
    }
}

function displayFeaturedProducts(products) {
    const featuredContainer = document.getElementById('featuredProducts');
    if (!featuredContainer) return;
    
    featuredContainer.innerHTML = products.map(product => `
        <div class="product-card" data-category="${product.category}">
            <div class="product-image">
                <img src="${product.image}" alt="${product.name}">
                <div class="product-badge">Featured</div>
                <div class="product-overlay">
                    <button class="quick-view-btn">Quick View</button>
                </div>
            </div>
            <div class="product-info">
                <h3 class="product-title">${product.name}</h3>
                <p class="product-description">${product.description}</p>
                <div class="product-price">GH₵ ${product.price}</div>
                <button class="add-to-cart-btn">Add to Cart</button>
            </div>
        </div>
    `).join('');
}

// Newsletter signup
function handleNewsletterSignup(form) {
    const email = form.querySelector('input[type="email"]').value;
    
    if (email) {
        // Simulate API call
        setTimeout(() => {
            showNotification('Thank you for subscribing!', 'success');
            form.reset();
        }, 1000);
    }
}

// Authentication - Removed old email-based login, using admin login instead

function checkAuthStatus() {
    // Check for admin authentication first
    const adminToken = localStorage.getItem('adminToken');
    if (adminToken) {
        const adminUser = JSON.parse(localStorage.getItem('adminUser') || '{}');
        currentUser = { ...adminUser, isAdmin: true };
        showAdminControls();
        return;
    }
    
    // Check for regular user authentication
    const userSession = localStorage.getItem('userSession');
    if (userSession) {
        try {
            const session = JSON.parse(userSession);
            currentUser = session.user;
            updateAuthUI();
        } catch (error) {
            console.error('Error parsing user session:', error);
            localStorage.removeItem('userSession');
        }
    }
    
    // Check Supabase session if available
    if (window.supabaseClient && window.supabaseClient.initialized) {
        const session = window.supabaseClient.getSession();
        if (session && session.user) {
            currentUser = session.user;
            updateAuthUI();
        }
    }
}

function updateAuthUI() {
    const loginBtn = document.getElementById('loginBtn');
    const adminBtn = document.getElementById('adminBtn');
    const logoutBtn = document.getElementById('logoutBtn');
    
    if (currentUser) {
        if (loginBtn) loginBtn.style.display = 'none';
        if (logoutBtn) logoutBtn.style.display = 'block';
        
        // Show admin button only for admin users
        if (adminBtn && currentUser.isAdmin) {
            adminBtn.style.display = 'block';
        } else if (adminBtn) {
            adminBtn.style.display = 'none';
        }
        
        // Update user display
        updateUserDisplay();
        
        localStorage.setItem('tsp_user', JSON.stringify(currentUser));
    } else {
        if (loginBtn) loginBtn.style.display = 'block';
        if (adminBtn) adminBtn.style.display = 'none';
        if (logoutBtn) logoutBtn.style.display = 'none';
        
        // Clear user display
        updateUserDisplay();
        
        localStorage.removeItem('tsp_user');
    }
}

function updateUserDisplay() {
    const welcomeElements = document.querySelectorAll('.welcome-user');
    
    if (currentUser) {
        const displayName = currentUser.name || currentUser.email || 'User';
        const welcomeText = currentUser.isAdmin ? `Admin: ${displayName}` : `Welcome, ${displayName}!`;
        
        welcomeElements.forEach(element => {
            element.textContent = welcomeText;
            element.style.display = 'inline';
        });
    } else {
        welcomeElements.forEach(element => {
            element.style.display = 'none';
        });
    }
    
    // Update any user name displays
    const userNameElements = document.querySelectorAll('.user-name');
    userNameElements.forEach(element => {
        element.textContent = currentUser ? (currentUser.name || currentUser.email || 'User') : '';
    });
}

// Admin dashboard access is handled by the admin authentication system

// Utility functions
function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.textContent = message;
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: ${type === 'success' ? '#4CAF50' : type === 'error' ? '#f44336' : '#2196F3'};
        color: white;
        padding: 1rem 2rem;
        border-radius: 8px;
        z-index: 10000;
        animation: slideIn 0.3s ease;
    `;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.style.animation = 'slideOut 0.3s ease';
        setTimeout(() => {
            if (document.body.contains(notification)) {
                document.body.removeChild(notification);
            }
        }, 300);
    }, 3000);
}

// Add CSS for notifications
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from { transform: translateX(100%); opacity: 0; }
        to { transform: translateX(0); opacity: 1; }
    }
    
    @keyframes slideOut {
        from { transform: translateX(0); opacity: 1; }
        to { transform: translateX(100%); opacity: 0; }
    }
    
    .modal {
        display: none;
        position: fixed;
        z-index: 2000;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0,0,0,0.5);
    }
    
    .modal-content {
        background-color: white;
        margin: 10% auto;
        padding: 2rem;
        border-radius: 10px;
        width: 90%;
        max-width: 400px;
        position: relative;
    }
    
    .close {
        position: absolute;
        right: 1rem;
        top: 1rem;
        font-size: 2rem;
        cursor: pointer;
        color: #666;
    }
    
    .close:hover {
        color: #000;
    }
    
    .modal-content h2 {
        margin-bottom: 1.5rem;
        text-align: center;
    }
    
    .modal-content form {
        display: flex;
        flex-direction: column;
        gap: 1rem;
    }
    
    .modal-content input {
        padding: 0.75rem;
        border: 2px solid #ddd;
        border-radius: 5px;
        font-size: 1rem;
    }
    
    .modal-content input:focus {
        outline: none;
        border-color: #ff6b35;
    }
    
    .cart-item {
        display: flex;
        align-items: center;
        gap: 1rem;
        padding: 1rem;
        border-bottom: 1px solid #eee;
    }
    
    .cart-item-info {
        flex: 1;
    }
    
    .cart-item-info h4 {
        margin-bottom: 0.5rem;
    }
    
    .remove-item {
        background: #f44336;
        color: white;
        border: none;
        padding: 0.5rem 1rem;
        border-radius: 5px;
        cursor: pointer;
    }
    
    .checkout-btn {
        margin-top: 1rem;
        width: 100%;
    }
`;
document.head.appendChild(style);
// About Page Specific Functionality
document.addEventListener('DOMContentLoaded', function() {
    // Scroll animations for about page
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, observerOptions);

    // Observe about page elements
    const aboutElements = document.querySelectorAll('.about-text, .about-sidebar, .team-member, .value-item');
    aboutElements.forEach(el => {
        observer.observe(el);
    });

    // Add hover effects for value items
    const valueItems = document.querySelectorAll('.value-item');
    valueItems.forEach(item => {
        item.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-5px) scale(1.02)';
        });
        
        item.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0) scale(1)';
        });
    });

    // Team member card interactions
    const teamMembers = document.querySelectorAll('.team-member');
    teamMembers.forEach(member => {
        member.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-10px) rotateY(2deg)';
        });
        
        member.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0) rotateY(0deg)';
        });
    });

    // Logo hover effect
    const aboutLogo = document.querySelector('.about-logo');
    if (aboutLogo) {
        aboutLogo.addEventListener('mouseenter', function() {
            this.style.transform = 'scale(1.05) rotate(2deg)';
        });
        
        aboutLogo.addEventListener('mouseleave', function() {
            this.style.transform = 'scale(1) rotate(0deg)';
        });
    }

    // Smooth scrolling for internal links
    const internalLinks = document.querySelectorAll('a[href^="#"]');
    internalLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const targetId = this.getAttribute('href').substring(1);
            const targetElement = document.getElementById(targetId);
            
            if (targetElement) {
                targetElement.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });

    // Add loading animation to page
    const aboutContent = document.querySelector('.about-content');
    if (aboutContent) {
        aboutContent.style.opacity = '0';
        aboutContent.style.transform = 'translateY(20px)';
        
        setTimeout(() => {
            aboutContent.style.transition = 'all 0.8s ease-out';
            aboutContent.style.opacity = '1';
            aboutContent.style.transform = 'translateY(0)';
        }, 100);
    }
});

// Counter animation for stats (if any stats are added later)
function animateCounter(element, target, duration = 2000) {
    let start = 0;
    const increment = target / (duration / 16);
    
    const timer = setInterval(() => {
        start += increment;
        element.textContent = Math.floor(start);
        
        if (start >= target) {
            element.textContent = target;
            clearInterval(timer);
        }
    }, 16);
}

// Parallax effect for about logo
window.addEventListener('scroll', function() {
    const aboutLogo = document.querySelector('.about-logo');
    if (aboutLogo) {
        const scrolled = window.pageYOffset;
        const parallax = scrolled * 0.1;
        aboutLogo.style.transform = `translateY(${parallax}px)`;
    }
});
// Admin Authentication Functions
function setupAdminAuth() {
    const adminBtn = document.getElementById('adminBtn');
    const loginBtn = document.getElementById('loginBtn');
    const logoutBtn = document.getElementById('logoutBtn');
    
    // Check if user is already logged in as admin
    const adminToken = localStorage.getItem('adminToken');
    if (adminToken) {
        showAdminControls();
    }
    
    // Setup admin button click
    if (adminBtn) {
        adminBtn.addEventListener('click', function() {
            window.location.href = 'admin.html';
        });
    }
    
    // Setup login button click
    if (loginBtn) {
        loginBtn.addEventListener('click', function() {
            showLoginModal();
        });
    }
    
    // Setup logout button click
    if (logoutBtn) {
        logoutBtn.addEventListener('click', function() {
            logout();
        });
    }
}

function showLoginModal() {
    // Create user authentication modal with tabs
    const modal = document.createElement('div');
    modal.className = 'modal auth-modal';
    modal.innerHTML = `
        <div class="modal-content">
            <span class="close">&times;</span>
            <div class="auth-tabs">
                <button class="auth-tab active" data-tab="login">Login</button>
                <button class="auth-tab" data-tab="signup">Sign Up</button>
                <button class="auth-tab" data-tab="admin">Admin</button>
            </div>
            
            <!-- User Login Form -->
            <div id="login-form" class="auth-form active">
                <h2>Welcome Back</h2>
                <form id="userLoginForm">
                    <div class="form-group">
                        <label for="loginEmail">Email</label>
                        <input type="email" id="loginEmail" required>
                    </div>
                    <div class="form-group">
                        <label for="loginPassword">Password</label>
                        <input type="password" id="loginPassword" required>
                    </div>
                    <button type="submit" class="btn-primary">Login</button>
                </form>
                <p class="auth-switch">Don't have an account? <a href="#" onclick="switchAuthTab('signup')">Sign up here</a></p>
            </div>
            
            <!-- User Signup Form -->
            <div id="signup-form" class="auth-form">
                <h2>Create Account</h2>
                <form id="userSignupForm">
                    <div class="form-group">
                        <label for="signupName">Full Name</label>
                        <input type="text" id="signupName" required>
                    </div>
                    <div class="form-group">
                        <label for="signupEmail">Email</label>
                        <input type="email" id="signupEmail" required>
                    </div>
                    <div class="form-group">
                        <label for="signupPassword">Password</label>
                        <input type="password" id="signupPassword" required minlength="6">
                    </div>
                    <div class="form-group">
                        <label for="signupConfirmPassword">Confirm Password</label>
                        <input type="password" id="signupConfirmPassword" required minlength="6">
                    </div>
                    <button type="submit" class="btn-primary">Create Account</button>
                </form>
                <p class="auth-switch">Already have an account? <a href="#" onclick="switchAuthTab('login')">Login here</a></p>
            </div>
            
            <!-- Admin Login Form -->
            <div id="admin-form" class="auth-form">
                <h2>Admin Access</h2>
                <form id="adminLoginForm">
                    <div class="form-group">
                        <label for="adminUsername">Username</label>
                        <input type="text" id="adminUsername" required>
                    </div>
                    <div class="form-group">
                        <label for="adminPassword">Password</label>
                        <input type="password" id="adminPassword" required>
                    </div>
                    <button type="submit" class="btn-primary">Login as Admin</button>
                </form>
                <p class="auth-switch">Regular user? <a href="#" onclick="switchAuthTab('login')">Login here</a></p>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    modal.style.display = 'block';
    
    // Setup tab switching
    setupAuthTabs(modal);
    
    // Setup form submissions
    setupUserLoginForm(modal);
    setupUserSignupForm(modal);
    setupAdminLoginForm(modal);
    
    // Setup close functionality
    const closeBtn = modal.querySelector('.close');
    closeBtn.onclick = () => closeModal();
    
    window.onclick = (event) => {
        if (event.target === modal) {
            closeModal();
        }
    };
    
    function closeModal() {
        modal.style.display = 'none';
        document.body.removeChild(modal);
    }
}

// Setup authentication tabs
function setupAuthTabs(modal) {
    const tabs = modal.querySelectorAll('.auth-tab');
    const forms = modal.querySelectorAll('.auth-form');
    
    tabs.forEach(tab => {
        tab.addEventListener('click', function() {
            const targetTab = this.getAttribute('data-tab');
            switchAuthTab(targetTab);
        });
    });
}

// Switch between authentication tabs
function switchAuthTab(tabName) {
    const tabs = document.querySelectorAll('.auth-tab');
    const forms = document.querySelectorAll('.auth-form');
    
    // Remove active class from all tabs and forms
    tabs.forEach(tab => tab.classList.remove('active'));
    forms.forEach(form => form.classList.remove('active'));
    
    // Add active class to selected tab and form
    document.querySelector(`[data-tab="${tabName}"]`).classList.add('active');
    document.getElementById(`${tabName}-form`).classList.add('active');
}

// Setup user login form
function setupUserLoginForm(modal) {
    const form = modal.querySelector('#userLoginForm');
    form.addEventListener('submit', async function(e) {
        e.preventDefault();
        
        const email = document.getElementById('loginEmail').value;
        const password = document.getElementById('loginPassword').value;
        
        try {
            showLoadingState(form, true);
            
            // Try Supabase authentication first
            if (window.supabaseClient && window.supabaseClient.initialized) {
                const result = await window.supabaseClient.signIn(email, password);
                
                if (result.success) {
                    currentUser = result.data.user;
                    if (result.data.session) {
                        localStorage.setItem('userSession', JSON.stringify(result.data.session));
                    }
                    updateAuthUI();
                    closeModal();
                    showWelcomeMessage(currentUser);
                    return;
                } else {
                    throw new Error(result.error);
                }
            }
            
            // Fallback to API
            const response = await fetch('/api/auth/login', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ email, password })
            });
            
            const data = await response.json();
            
            if (data.success) {
                currentUser = data.user;
                
                // Store session for persistence
                if (data.session) {
                    localStorage.setItem('userSession', JSON.stringify(data.session));
                }
                
                updateAuthUI();
                closeModal();
                showWelcomeMessage(currentUser);
            } else {
                throw new Error(data.message || 'Login failed');
            }
            
        } catch (error) {
            console.error('Login error:', error);
            showErrorMessage(error.message || 'Login failed. Please check your credentials.');
        } finally {
            showLoadingState(form, false);
        }
    });
}

// Setup user signup form
function setupUserSignupForm(modal) {
    const form = modal.querySelector('#userSignupForm');
    form.addEventListener('submit', async function(e) {
        e.preventDefault();
        
        const name = document.getElementById('signupName').value;
        const email = document.getElementById('signupEmail').value;
        const password = document.getElementById('signupPassword').value;
        const confirmPassword = document.getElementById('signupConfirmPassword').value;
        
        // Validate passwords match
        if (password !== confirmPassword) {
            showErrorMessage('Passwords do not match');
            return;
        }
        
        try {
            showLoadingState(form, true);
            
            // Try Supabase authentication first
            if (window.supabaseClient && window.supabaseClient.initialized) {
                const result = await window.supabaseClient.signUp(email, password, { name });
                
                if (result.success) {
                    showSuccessMessage('Account created successfully! Please check your email to verify your account.');
                    switchAuthTab('login');
                    return;
                } else {
                    throw new Error(result.error);
                }
            }
            
            // Fallback to API
            const response = await fetch('/api/auth/signup', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ name, email, password })
            });
            
            const data = await response.json();
            
            if (data.success) {
                // Store user session if provided
                if (data.session) {
                    localStorage.setItem('userSession', JSON.stringify(data.session));
                    currentUser = data.user;
                    updateAuthUI();
                    closeModal();
                    showSuccessMessage('Account created and logged in successfully!');
                } else {
                    showSuccessMessage('Account created successfully! You can now login.');
                    switchAuthTab('login');
                }
            } else {
                throw new Error(data.message || 'Signup failed');
            }
            
        } catch (error) {
            console.error('Signup error:', error);
            showErrorMessage(error.message || 'Signup failed. Please try again.');
        } finally {
            showLoadingState(form, false);
        }
    });
}

// Setup admin login form
function setupAdminLoginForm(modal) {
    const form = modal.querySelector('#adminLoginForm');
    form.addEventListener('submit', async function(e) {
        e.preventDefault();
        
        const username = document.getElementById('adminUsername').value;
        const password = document.getElementById('adminPassword').value;
        
        try {
            showLoadingState(form, true);
            
            // Check admin credentials
            if (username === 'admin' && password === 'admin123') {
                // Set admin token and user info
                localStorage.setItem('adminToken', 'admin-token-' + Date.now());
                localStorage.setItem('adminUser', JSON.stringify({
                    username: username,
                    name: 'Administrator',
                    role: 'admin'
                }));
                
                currentUser = {
                    id: 'admin',
                    username: username,
                    name: 'Administrator',
                    role: 'admin',
                    isAdmin: true
                };
                
                showAdminControls();
                closeModal();
                showSuccessMessage('Successfully logged in as admin!');
            } else {
                // Try API fallback for admin login
                const response = await fetch('/api/auth/admin-login', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({ username, password })
                });
                
                const data = await response.json();
                
                if (data.success) {
                    localStorage.setItem('adminToken', data.token);
                    localStorage.setItem('adminUser', JSON.stringify(data.user));
                    
                    currentUser = data.user;
                    showAdminControls();
                    closeModal();
                    showSuccessMessage('Successfully logged in as admin!');
                } else {
                    throw new Error(data.message || 'Invalid admin credentials');
                }
            }
            
        } catch (error) {
            console.error('Admin login error:', error);
            showErrorMessage(error.message || 'Invalid admin credentials. Please try again.');
        } finally {
            showLoadingState(form, false);
        }
    });
}

// Show loading state on forms
function showLoadingState(form, loading) {
    const submitBtn = form.querySelector('button[type="submit"]');
    const originalText = submitBtn.textContent;
    
    if (loading) {
        submitBtn.disabled = true;
        submitBtn.textContent = 'Please wait...';
        submitBtn.style.opacity = '0.7';
    } else {
        submitBtn.disabled = false;
        submitBtn.textContent = originalText;
        submitBtn.style.opacity = '1';
    }
}

// Close modal function
function closeModal() {
    const modal = document.querySelector('.modal');
    if (modal) {
        modal.style.display = 'none';
        document.body.removeChild(modal);
    }
}

function showAdminControls() {
    const adminBtn = document.getElementById('adminBtn');
    const loginBtn = document.getElementById('loginBtn');
    const logoutBtn = document.getElementById('logoutBtn');
    
    if (adminBtn) adminBtn.style.display = 'block';
    if (loginBtn) loginBtn.style.display = 'none';
    if (logoutBtn) logoutBtn.style.display = 'block';
    
    // Update current user state
    const adminUser = JSON.parse(localStorage.getItem('adminUser') || '{}');
    currentUser = { ...adminUser, isAdmin: true };
    
    // Update admin username display
    const usernameEl = document.getElementById('adminUsername');
    if (usernameEl && adminUser.name) {
        usernameEl.textContent = adminUser.name;
    }
}

function logout() {
    // Clear all authentication data
    localStorage.removeItem('adminToken');
    localStorage.removeItem('adminUser');
    localStorage.removeItem('userSession');
    localStorage.removeItem('tsp_user');
    
    // Sign out from Supabase if available
    if (window.supabaseClient && window.supabaseClient.initialized) {
        window.supabaseClient.signOut();
    }
    
    // Reset current user state
    currentUser = null;
    
    const adminBtn = document.getElementById('adminBtn');
    const loginBtn = document.getElementById('loginBtn');
    const logoutBtn = document.getElementById('logoutBtn');
    
    if (adminBtn) adminBtn.style.display = 'none';
    if (loginBtn) loginBtn.style.display = 'block';
    if (logoutBtn) logoutBtn.style.display = 'none';
    
    // Clear user displays
    updateUserDisplay();
    
    showSuccessMessage('Successfully logged out!');
}

function showSuccessMessage(message) {
    showNotification(message, 'success');
}

function showErrorMessage(message) {
    showNotification(message, 'error');
}

function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.innerHTML = `
        <i class="fas fa-${type === 'success' ? 'check-circle' : type === 'error' ? 'exclamation-circle' : 'info-circle'}"></i>
        <span>${message}</span>
    `;
    
    // Style the notification
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: white;
        padding: 1rem 1.5rem;
        border-radius: 10px;
        box-shadow: 0 5px 20px rgba(0,0,0,0.2);
        display: flex;
        align-items: center;
        gap: 0.5rem;
        z-index: 10000;
        animation: slideInRight 0.3s ease-out;
        border-left: 4px solid ${type === 'success' ? '#4caf50' : type === 'error' ? '#f44336' : '#2196f3'};
    `;
    
    document.body.appendChild(notification);
    
    // Auto remove after 3 seconds
    setTimeout(() => {
        if (notification.parentElement) {
            notification.style.animation = 'slideOutRight 0.3s ease-out';
            setTimeout(() => {
                notification.remove();
            }, 300);
        }
    }, 3000);
}

// Load products from admin if available
function loadAdminProducts() {
    const adminProducts = JSON.parse(localStorage.getItem('websiteProducts') || '[]');
    if (adminProducts.length > 0) {
        // Merge admin products with existing products
        const existingProducts = [...allProducts];
        
        adminProducts.forEach(adminProduct => {
            const existingIndex = existingProducts.findIndex(p => p.id === adminProduct.id);
            if (existingIndex >= 0) {
                existingProducts[existingIndex] = adminProduct;
            } else {
                existingProducts.push(adminProduct);
            }
        });
        
        // Update the global products array
        if (typeof allProducts !== 'undefined') {
            allProducts.length = 0;
            allProducts.push(...existingProducts);
        }
        
        // Refresh product displays
        if (typeof loadAllProducts === 'function') {
            loadAllProducts();
        }
        
        if (typeof displayProducts === 'function' && typeof filteredProducts !== 'undefined') {
            displayProducts(filteredProducts);
        }
    }
}

// Initialize admin functionality
document.addEventListener('DOMContentLoaded', function() {
    setupAdminAuth();
    loadAdminProducts();
});

// Add CSS for notifications
const notificationStyle = document.createElement('style');
notificationStyle.textContent = `
    @keyframes slideInRight {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    @keyframes slideOutRight {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(100%);
            opacity: 0;
        }
    }
    
    .admin-login-modal .modal-content {
        max-width: 400px;
    }
    
    .admin-login-modal .form-group {
        margin-bottom: 1rem;
    }
    
    .admin-login-modal label {
        display: block;
        margin-bottom: 0.5rem;
        font-weight: 500;
        color: #333;
    }
    
    .admin-login-modal input {
        width: 100%;
        padding: 0.8rem;
        border: 2px solid #ddd;
        border-radius: 8px;
        font-size: 1rem;
    }
    
    .admin-login-modal input:focus {
        outline: none;
        border-color: #667eea;
    }
`;
document.head.appendChild(notificationStyle);
// Form validation helpers
function validateEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

function validatePassword(password) {
    return password.length >= 6;
}

function showFieldError(fieldId, message) {
    const field = document.getElementById(fieldId);
    const formGroup = field.closest('.form-group');
    
    formGroup.classList.add('error');
    formGroup.classList.remove('success');
    
    let errorElement = formGroup.querySelector('.form-error');
    if (!errorElement) {
        errorElement = document.createElement('div');
        errorElement.className = 'form-error';
        formGroup.appendChild(errorElement);
    }
    errorElement.textContent = message;
}

function showFieldSuccess(fieldId) {
    const field = document.getElementById(fieldId);
    const formGroup = field.closest('.form-group');
    
    formGroup.classList.add('success');
    formGroup.classList.remove('error');
    
    const errorElement = formGroup.querySelector('.form-error');
    if (errorElement) {
        errorElement.style.display = 'none';
    }
}

function clearFieldValidation(fieldId) {
    const field = document.getElementById(fieldId);
    const formGroup = field.closest('.form-group');
    
    formGroup.classList.remove('error', 'success');
    
    const errorElement = formGroup.querySelector('.form-error');
    if (errorElement) {
        errorElement.style.display = 'none';
    }
}

// Add real-time validation to forms
function setupFormValidation() {
    // Email validation
    document.addEventListener('input', function(e) {
        if (e.target.type === 'email') {
            const email = e.target.value;
            if (email && !validateEmail(email)) {
                showFieldError(e.target.id, 'Please enter a valid email address');
            } else if (email && validateEmail(email)) {
                showFieldSuccess(e.target.id);
            } else {
                clearFieldValidation(e.target.id);
            }
        }
    });
    
    // Password validation
    document.addEventListener('input', function(e) {
        if (e.target.type === 'password' && e.target.id.includes('Password')) {
            const password = e.target.value;
            if (password && !validatePassword(password)) {
                showFieldError(e.target.id, 'Password must be at least 6 characters long');
            } else if (password && validatePassword(password)) {
                showFieldSuccess(e.target.id);
            } else {
                clearFieldValidation(e.target.id);
            }
        }
    });
    
    // Confirm password validation
    document.addEventListener('input', function(e) {
        if (e.target.id === 'signupConfirmPassword') {
            const password = document.getElementById('signupPassword').value;
            const confirmPassword = e.target.value;
            
            if (confirmPassword && password !== confirmPassword) {
                showFieldError(e.target.id, 'Passwords do not match');
            } else if (confirmPassword && password === confirmPassword) {
                showFieldSuccess(e.target.id);
            } else {
                clearFieldValidation(e.target.id);
            }
        }
    });
}

// Initialize form validation when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    setupFormValidation();
});

// Enhanced user experience functions
function showWelcomeMessage(user) {
    const message = user.isAdmin ? 
        `Welcome back, Administrator!` : 
        `Welcome back, ${user.name || user.email}!`;
    
    showSuccessMessage(message);
}

// Auto-login check on page load
function autoLoginCheck() {
    // Check if user was previously logged in
    const savedUser = localStorage.getItem('tsp_user');
    if (savedUser) {
        try {
            const user = JSON.parse(savedUser);
            currentUser = user;
            updateAuthUI();
        } catch (error) {
            console.error('Error parsing saved user:', error);
            localStorage.removeItem('tsp_user');
        }
    }
}

// Call auto-login check when page loads
document.addEventListener('DOMContentLoaded', function() {
    autoLoginCheck();
});