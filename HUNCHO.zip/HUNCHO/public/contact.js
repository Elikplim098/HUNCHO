// Contact page specific functionality
document.addEventListener('DOMContentLoaded', function() {
    setupContactForm();
});

function setupContactForm() {
    const contactForm = document.getElementById('contactForm');
    
    if (contactForm) {
        contactForm.addEventListener('submit', handleContactSubmit);
    }
}

function handleContactSubmit(e) {
    e.preventDefault();
    
    const formData = new FormData(e.target);
    const contactData = {
        name: formData.get('name'),
        email: formData.get('email'),
        phone: formData.get('phone'),
        subject: formData.get('subject'),
        message: formData.get('message')
    };
    
    // Validate form
    if (!contactData.name || !contactData.email || !contactData.subject || !contactData.message) {
        showNotification('Please fill in all required fields.', 'error');
        return;
    }
    
    // Simulate form submission
    const submitButton = e.target.querySelector('button[type="submit"]');
    const originalText = submitButton.textContent;
    
    submitButton.textContent = 'Sending...';
    submitButton.disabled = true;
    
    setTimeout(() => {
        showNotification('Thank you for your message! We\'ll get back to you soon.', 'success');
        e.target.reset();
        submitButton.textContent = originalText;
        submitButton.disabled = false;
    }, 1500);
}

// Add contact page specific styles
const contactStyle = document.createElement('style');
contactStyle.textContent = `
    .contact-content {
        padding: 5rem 0;
        background: white;
    }
    
    .contact-grid {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 4rem;
    }
    
    .contact-info-section h2,
    .contact-form-section h2 {
        font-size: 2rem;
        margin-bottom: 2rem;
        color: #333;
    }
    
    .contact-info {
        margin-bottom: 3rem;
    }
    
    .contact-item {
        display: flex;
        align-items: flex-start;
        gap: 1rem;
        margin-bottom: 2rem;
        padding: 1rem;
        background: #f8f9fa;
        border-radius: 10px;
    }
    
    .contact-item i {
        font-size: 1.5rem;
        color: #667eea;
        margin-top: 0.2rem;
    }
    
    .contact-item h4 {
        margin-bottom: 0.5rem;
        color: #333;
    }
    
    .contact-item p {
        color: #666;
        margin: 0;
    }
    
    .social-media h3 {
        margin-bottom: 1rem;
        color: #333;
    }
    
    .contact-form {
        display: flex;
        flex-direction: column;
        gap: 1.5rem;
    }
    
    .form-group {
        display: flex;
        flex-direction: column;
    }
    
    .contact-form input,
    .contact-form select,
    .contact-form textarea {
        padding: 1rem;
        border: 2px solid #ddd;
        border-radius: 8px;
        font-size: 1rem;
        transition: border-color 0.3s;
        font-family: inherit;
    }
    
    .contact-form input:focus,
    .contact-form select:focus,
    .contact-form textarea:focus {
        outline: none;
        border-color: #667eea;
    }
    
    .contact-form textarea {
        resize: vertical;
        min-height: 120px;
    }
    
    .contact-form button {
        align-self: flex-start;
        min-width: 150px;
    }
    
    .map-section {
        padding: 5rem 0;
        background: #f8f9fa;
    }
    
    .map-section h2 {
        text-align: center;
        font-size: 2.5rem;
        margin-bottom: 3rem;
        color: #333;
    }
    
    .map-container {
        border-radius: 15px;
        overflow: hidden;
        box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        margin-bottom: 2rem;
    }
    
    .map-info {
        text-align: center;
        max-width: 600px;
        margin: 0 auto;
    }
    
    .map-info p {
        font-size: 1.1rem;
        color: #666;
        line-height: 1.6;
    }
    
    @media (max-width: 768px) {
        .contact-grid {
            grid-template-columns: 1fr;
            gap: 2rem;
        }
        
        .contact-form button {
            align-self: stretch;
        }
        
        .map-container iframe {
            height: 300px;
        }
    }
`;
document.head.appendChild(contactStyle);
// Footer functionality for contact page
document.addEventListener('DOMContentLoaded', function() {
    // Add smooth scroll to footer links
    const footerLinks = document.querySelectorAll('.footer a[href^="#"]');
    footerLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const targetId = this.getAttribute('href').substring(1);
            const targetElement = document.getElementById(targetId);
            
            if (targetElement) {
                targetElement.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
    
    // Add hover effects to footer social links
    const socialLinks = document.querySelectorAll('.footer .social-link');
    socialLinks.forEach(link => {
        link.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-3px) scale(1.1)';
        });
        
        link.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0) scale(1)';
        });
    });
});