// Admin Dashboard JavaScript
document.addEventListener('DOMContentLoaded', function() {
    initializeAdmin();
});

// Admin state management
let adminData = {
    products: JSON.parse(localStorage.getItem('adminProducts')) || [],
    orders: JSON.parse(localStorage.getItem('adminOrders')) || [],
    users: JSON.parse(localStorage.getItem('adminUsers')) || [],
    currentSection: 'dashboard'
};

// Initialize admin dashboard
function initializeAdmin() {
    // Check if user is authenticated as admin
    if (!isAdminAuthenticated()) {
        redirectToLogin();
        return;
    }
    
    setupNavigation();
    loadDashboardData();
    setupEventListeners();
    updateDashboardStats();
}

// Check admin authentication
function isAdminAuthenticated() {
    const adminToken = localStorage.getItem('adminToken');
    const adminUser = localStorage.getItem('adminUser');
    
    // Check for admin token
    if (adminToken && adminUser) {
        return true;
    }
    
    // Check for user session with admin role
    const userSession = localStorage.getItem('userSession');
    if (userSession) {
        try {
            const session = JSON.parse(userSession);
            if (session.user && session.user.role === 'admin') {
                return true;
            }
        } catch (error) {
            console.error('Error parsing user session:', error);
        }
    }
    
    return false;
}

// Redirect to login if not authenticated
function redirectToLogin() {
    window.location.href = 'index.html';
}

// Setup navigation
function setupNavigation() {
    const navLinks = document.querySelectorAll('.admin-nav-link');
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const section = this.getAttribute('data-section');
            showSection(section);
        });
    });
}

// Show specific section
function showSection(sectionName) {
    // Update navigation
    document.querySelectorAll('.admin-nav-link').forEach(link => {
        link.classList.remove('active');
    });
    document.querySelector(`[data-section="${sectionName}"]`).classList.add('active');
    
    // Update content
    document.querySelectorAll('.admin-section').forEach(section => {
        section.classList.remove('active');
    });
    document.getElementById(`${sectionName}-section`).classList.add('active');
    
    adminData.currentSection = sectionName;
    
    // Load section-specific data
    switch(sectionName) {
        case 'products':
            loadProducts();
            break;
        case 'orders':
            loadOrders();
            break;
        case 'users':
            loadUsers();
            break;
        case 'analytics':
            loadAnalytics();
            break;
    }
}

// Setup event listeners
function setupEventListeners() {
    // Product form submission
    const productForm = document.getElementById('productForm');
    if (productForm) {
        productForm.addEventListener('submit', handleProductSubmit);
    }
    
    // File upload handling
    const fileInput = document.getElementById('productImages');
    if (fileInput) {
        fileInput.addEventListener('change', handleFileUpload);
    }
    
    // Search and filter functionality
    setupSearchAndFilters();
}

// Handle product form submission
async function handleProductSubmit(e) {
    e.preventDefault();
    
    showLoading(true);
    
    try {
        const formData = new FormData(e.target);
        const files = document.getElementById('productImages').files;
        
        // Process uploaded images first
        let productImages = [];
        let primaryImage = '';
        
        if (files.length > 0) {
            // Convert uploaded files to base64 or object URLs for immediate display
            for (let file of files) {
                if (file.type.startsWith('image/')) {
                    const imageUrl = URL.createObjectURL(file);
                    productImages.push(imageUrl);
                }
            }
            primaryImage = productImages[0] || '';
        }
        
        // If no images uploaded, use placeholder
        if (productImages.length === 0) {
            const placeholderImage = `assets/products/${generateImageName(formData.get('name'))}.jpg`;
            productImages = [placeholderImage];
            primaryImage = placeholderImage;
        }
        
        const productData = {
            name: formData.get('name'),
            description: formData.get('description'),
            price: parseFloat(formData.get('price')),
            category: formData.get('category'),
            sizes: formData.get('sizes') ? formData.get('sizes').split(',').map(s => s.trim()) : [],
            colors: formData.get('colors') ? formData.get('colors').split(',').map(c => c.trim()) : [],
            stock: parseInt(formData.get('stock')) || 0,
            featured: formData.get('featured') === 'on',
            active: formData.get('active') === 'on',
            primary_image: primaryImage,
            images: productImages,
            sku: generateSKU(formData.get('category'), formData.get('name')),
            tags: [formData.get('category'), formData.get('name').toLowerCase()],
            uploaded_images: files.length > 0 // Flag to indicate real images were uploaded
        };
        
        // Get admin token for authentication
        const adminToken = localStorage.getItem('adminToken');
        const userSession = localStorage.getItem('userSession');
        
        let authHeader = '';
        if (adminToken) {
            authHeader = `Bearer ${adminToken}`;
        } else if (userSession) {
            const session = JSON.parse(userSession);
            authHeader = `Bearer ${session.access_token}`;
        }
        
        // Send to server API
        const response = await fetch('/api/admin/products', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': authHeader
            },
            body: JSON.stringify(productData)
        });
        
        const result = await response.json();
        
        if (result.success) {
            // Add to local storage for immediate UI update
            const newProduct = result.product || productData;
            newProduct.id = newProduct.id || Date.now();
            
            adminData.products.push(newProduct);
            localStorage.setItem('adminProducts', JSON.stringify(adminData.products));
            
            // Update main products data
            updateMainProductsData();
            
            showMessage('Product added successfully!', 'success');
            hideAddProductForm();
            loadProducts();
            updateDashboardStats();
        } else {
            // Fallback to localStorage if API fails
            console.log('API failed, using localStorage fallback:', result.message);
            
            productData.id = Date.now();
            productData.created_at = new Date().toISOString();
            productData.updated_at = new Date().toISOString();
            
            adminData.products.push(productData);
            localStorage.setItem('adminProducts', JSON.stringify(adminData.products));
            updateMainProductsData();
            
            showMessage('Product added successfully (local storage)!', 'success');
            hideAddProductForm();
            loadProducts();
            updateDashboardStats();
        }
        
    } catch (error) {
        console.error('Error adding product:', error);
        
        // Fallback to localStorage on error
        try {
            const formData = new FormData(e.target);
            const files = document.getElementById('productImages').files;
            
            let productImages = [];
            let primaryImage = '';
            
            if (files.length > 0) {
                for (let file of files) {
                    if (file.type.startsWith('image/')) {
                        const imageUrl = URL.createObjectURL(file);
                        productImages.push(imageUrl);
                    }
                }
                primaryImage = productImages[0] || '';
            }
            
            if (productImages.length === 0) {
                const placeholderImage = `assets/products/${generateImageName(formData.get('name'))}.jpg`;
                productImages = [placeholderImage];
                primaryImage = placeholderImage;
            }
            
            const productData = {
                id: Date.now(),
                name: formData.get('name'),
                description: formData.get('description'),
                price: parseFloat(formData.get('price')),
                category: formData.get('category'),
                sizes: formData.get('sizes') ? formData.get('sizes').split(',').map(s => s.trim()) : [],
                colors: formData.get('colors') ? formData.get('colors').split(',').map(c => c.trim()) : [],
                stock: parseInt(formData.get('stock')) || 0,
                featured: formData.get('featured') === 'on',
                active: formData.get('active') === 'on',
                primary_image: primaryImage,
                images: productImages,
                created_at: new Date().toISOString(),
                updated_at: new Date().toISOString(),
                uploaded_images: files.length > 0
            };
            
            adminData.products.push(productData);
            localStorage.setItem('adminProducts', JSON.stringify(adminData.products));
            updateMainProductsData();
            
            showMessage('Product added successfully (offline mode)!', 'success');
            hideAddProductForm();
            loadProducts();
            updateDashboardStats();
        } catch (fallbackError) {
            showMessage('Error adding product. Please try again.', 'error');
        }
    } finally {
        showLoading(false);
    }
}

// Generate SKU
function generateSKU(category, name) {
    const categoryMap = {
        't-shirts': 'TEE',
        'hoodies': 'HOOD',
        'pants': 'PANT',
        'accessories': 'ACC'
    };
    
    const categoryCode = categoryMap[category] || 'PROD';
    const nameCode = name.toUpperCase().replace(/[^A-Z0-9]/g, '').substring(0, 4);
    const timestamp = Date.now().toString().slice(-4);
    
    return `TSP-${categoryCode}-${nameCode}-${timestamp}`;
}

// Generate placeholder name
function generatePlaceholder(category, name) {
    const categoryMap = {
        't-shirts': 'tshirt',
        'hoodies': 'hoodie',
        'pants': 'pants',
        'accessories': 'accessory'
    };
    
    const baseCategory = categoryMap[category] || 'product';
    const cleanName = name.toLowerCase().replace(/[^a-z0-9]/g, '-');
    return `${baseCategory}-${cleanName}`;
}

// Generate image name
function generateImageName(name) {
    return name.toLowerCase().replace(/[^a-z0-9]/g, '-').replace(/^tsp-/, '').replace(/--+/g, '-');
}

// Process image uploads
async function processImageUploads(files) {
    const imageUrls = [];
    
    for (let file of files) {
        if (file.size > 5 * 1024 * 1024) { // 5MB limit
            throw new Error(`File ${file.name} is too large. Maximum size is 5MB.`);
        }
        
        // In a real application, you would upload to a server
        // For now, we'll create object URLs for preview
        const imageUrl = URL.createObjectURL(file);
        imageUrls.push(imageUrl);
    }
    
    return imageUrls;
}

// Handle file upload preview
function handleFileUpload(e) {
    const files = e.target.files;
    const preview = document.getElementById('imagePreview');
    preview.innerHTML = '';
    
    Array.from(files).forEach((file, index) => {
        if (file.type.startsWith('image/')) {
            const reader = new FileReader();
            reader.onload = function(e) {
                const imageContainer = document.createElement('div');
                imageContainer.className = 'preview-image-container';
                imageContainer.innerHTML = `
                    <img src="${e.target.result}" class="preview-image" alt="Product preview ${index + 1}">
                    <div class="image-info">
                        <span class="image-name">${file.name}</span>
                        <span class="image-size">${(file.size / 1024).toFixed(1)} KB</span>
                    </div>
                    <button type="button" class="remove-image-btn" onclick="removePreviewImage(this)">
                        <i class="fas fa-times"></i>
                    </button>
                `;
                preview.appendChild(imageContainer);
            };
            reader.readAsDataURL(file);
        }
    });
}

// Remove preview image
function removePreviewImage(button) {
    const container = button.closest('.preview-image-container');
    container.remove();
    
    // Clear the file input if no images left
    const preview = document.getElementById('imagePreview');
    if (preview.children.length === 0) {
        document.getElementById('productImages').value = '';
    }
}

// Update main products data (for the main website)
function updateMainProductsData() {
    // This would typically sync with the main products.js file
    // For now, we'll update localStorage that the main site can read
    const mainProducts = adminData.products.filter(p => p.active).map(product => ({
        id: product.id,
        name: product.name,
        description: product.description,
        price: product.price,
        category: product.category,
        image: product.image,
        placeholder: product.placeholder,
        sizes: product.sizes,
        colors: product.colors,
        featured: product.featured
    }));
    
    localStorage.setItem('websiteProducts', JSON.stringify(mainProducts));
}

// Load products for admin table
function loadProducts() {
    const tbody = document.getElementById('productsTableBody');
    if (!tbody) return;
    
    tbody.innerHTML = '';
    
    adminData.products.forEach(product => {
        const row = document.createElement('tr');
        
        // Use uploaded image if available, otherwise use placeholder
        const productImage = product.primary_image || product.image || 'sp-logo.jpeg';
        const imageClass = product.uploaded_images ? 'uploaded-image' : 'placeholder-image';
        
        row.innerHTML = `
            <td>
                <div class="product-image-cell">
                    <img src="${productImage}" alt="${product.name}" 
                         class="table-product-image ${imageClass}"
                         onerror="this.src='sp-logo.jpeg'; this.classList.add('fallback-image');">
                    ${product.uploaded_images ? '<span class="image-indicator">📷</span>' : '<span class="image-indicator">🖼️</span>'}
                </div>
            </td>
            <td>
                <div class="product-name-cell">
                    <strong>${product.name}</strong>
                    <small>${product.description.substring(0, 50)}...</small>
                </div>
            </td>
            <td><span class="category-badge ${product.category}">${product.category}</span></td>
            <td><strong>GH₵ ${product.price.toFixed(2)}</strong></td>
            <td>
                <span class="stock-badge ${product.stock > 0 ? 'in-stock' : 'out-of-stock'}">
                    ${product.stock}
                </span>
            </td>
            <td>
                <div class="status-badges">
                    ${product.active ? '<span class="status-badge active">Active</span>' : '<span class="status-badge inactive">Inactive</span>'}
                    ${product.featured ? '<span class="status-badge featured">Featured</span>' : ''}
                    ${product.uploaded_images ? '<span class="status-badge uploaded">Custom Image</span>' : ''}
                </div>
            </td>
            <td>
                <div class="action-buttons">
                    <button class="btn-icon" onclick="editProduct(${product.id})" title="Edit">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="btn-icon" onclick="toggleProductStatus(${product.id})" title="Toggle Status">
                        <i class="fas fa-toggle-${product.active ? 'on' : 'off'}"></i>
                    </button>
                    <button class="btn-icon danger" onclick="deleteProduct(${product.id})" title="Delete">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </td>
        `;
        tbody.appendChild(row);
    });
}

// Product management functions
async function editProduct(productId) {
    const product = adminData.products.find(p => p.id === productId);
    if (!product) return;
    
    // Populate form with product data
    document.getElementById('productName').value = product.name;
    document.getElementById('productDescription').value = product.description;
    document.getElementById('productPrice').value = product.price;
    document.getElementById('productCategory').value = product.category;
    document.getElementById('productSizes').value = Array.isArray(product.sizes) ? product.sizes.join(', ') : product.sizes || '';
    document.getElementById('productColors').value = Array.isArray(product.colors) ? product.colors.join(', ') : product.colors || '';
    document.getElementById('productStock').value = product.stock;
    document.getElementById('productFeatured').checked = product.featured;
    document.getElementById('productActive').checked = product.active;
    
    // Show form
    showAddProductForm();
    
    // Update form title and button
    document.querySelector('.form-header h2').textContent = 'Edit Product';
    document.querySelector('.form-actions .btn-primary').innerHTML = '<i class="fas fa-save"></i> Update Product';
    
    // Store editing product ID
    document.getElementById('productForm').dataset.editingId = productId;
}

async function toggleProductStatus(productId) {
    const product = adminData.products.find(p => p.id === productId);
    if (!product) return;
    
    try {
        const updatedProduct = { ...product, active: !product.active };
        
        // Get admin token for authentication
        const adminToken = localStorage.getItem('adminToken');
        const userSession = localStorage.getItem('userSession');
        
        let authHeader = '';
        if (adminToken) {
            authHeader = `Bearer ${adminToken}`;
        } else if (userSession) {
            const session = JSON.parse(userSession);
            authHeader = `Bearer ${session.access_token}`;
        }
        
        // Try API first
        const response = await fetch(`/api/admin/products/${productId}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': authHeader
            },
            body: JSON.stringify({ active: updatedProduct.active })
        });
        
        const result = await response.json();
        
        if (result.success) {
            // Update local data
            product.active = updatedProduct.active;
            localStorage.setItem('adminProducts', JSON.stringify(adminData.products));
            updateMainProductsData();
            loadProducts();
            showMessage(`Product ${product.active ? 'activated' : 'deactivated'} successfully!`, 'success');
        } else {
            throw new Error(result.message);
        }
        
    } catch (error) {
        console.error('Error toggling product status:', error);
        
        // Fallback to localStorage
        product.active = !product.active;
        localStorage.setItem('adminProducts', JSON.stringify(adminData.products));
        updateMainProductsData();
        loadProducts();
        showMessage(`Product ${product.active ? 'activated' : 'deactivated'} successfully (offline)!`, 'success');
    }
}

async function deleteProduct(productId) {
    if (!confirm('Are you sure you want to delete this product?')) return;
    
    try {
        // Get admin token for authentication
        const adminToken = localStorage.getItem('adminToken');
        const userSession = localStorage.getItem('userSession');
        
        let authHeader = '';
        if (adminToken) {
            authHeader = `Bearer ${adminToken}`;
        } else if (userSession) {
            const session = JSON.parse(userSession);
            authHeader = `Bearer ${session.access_token}`;
        }
        
        // Try API first
        const response = await fetch(`/api/admin/products/${productId}`, {
            method: 'DELETE',
            headers: {
                'Authorization': authHeader
            }
        });
        
        const result = await response.json();
        
        if (result.success) {
            // Update local data
            adminData.products = adminData.products.filter(p => p.id !== productId);
            localStorage.setItem('adminProducts', JSON.stringify(adminData.products));
            updateMainProductsData();
            loadProducts();
            updateDashboardStats();
            showMessage('Product deleted successfully!', 'success');
        } else {
            throw new Error(result.message);
        }
        
    } catch (error) {
        console.error('Error deleting product:', error);
        
        // Fallback to localStorage
        adminData.products = adminData.products.filter(p => p.id !== productId);
        localStorage.setItem('adminProducts', JSON.stringify(adminData.products));
        updateMainProductsData();
        loadProducts();
        updateDashboardStats();
        showMessage('Product deleted successfully (offline)!', 'success');
    }
}

// Dashboard functions
function updateDashboardStats() {
    document.getElementById('totalProducts').textContent = adminData.products.length;
    document.getElementById('totalOrders').textContent = adminData.orders.length;
    document.getElementById('totalUsers').textContent = adminData.users.length;
    
    const totalRevenue = adminData.orders.reduce((sum, order) => sum + (order.total || 0), 0);
    document.getElementById('totalRevenue').textContent = `GH₵ ${totalRevenue.toFixed(2)}`;
}

function loadDashboardData() {
    // Load recent activity
    const activityContainer = document.getElementById('recentActivity');
    if (activityContainer) {
        const activities = [
            { type: 'product', message: 'New product added', time: '2 hours ago', icon: 'fas fa-plus' },
            { type: 'order', message: 'Order #1234 completed', time: '4 hours ago', icon: 'fas fa-check' },
            { type: 'user', message: 'New user registered', time: '6 hours ago', icon: 'fas fa-user-plus' }
        ];
        
        activityContainer.innerHTML = activities.map(activity => `
            <div class="activity-item">
                <div class="activity-icon">
                    <i class="${activity.icon}"></i>
                </div>
                <div class="activity-content">
                    <p>${activity.message}</p>
                    <small>${activity.time}</small>
                </div>
            </div>
        `).join('');
    }
}

// UI Helper functions
function showAddProductForm() {
    document.getElementById('addProductForm').style.display = 'block';
    document.body.style.overflow = 'hidden';
}

function hideAddProductForm() {
    document.getElementById('addProductForm').style.display = 'none';
    document.body.style.overflow = 'auto';
    
    // Reset form
    document.getElementById('productForm').reset();
    document.getElementById('imagePreview').innerHTML = '';
    
    // Reset form title and button
    document.querySelector('.form-header h2').textContent = 'Add New Product';
    document.querySelector('.form-actions .btn-primary').innerHTML = '<i class="fas fa-save"></i> Save Product';
    
    // Remove editing ID
    delete document.getElementById('productForm').dataset.editingId;
}

function showLoading(show) {
    const overlay = document.getElementById('loadingOverlay');
    overlay.style.display = show ? 'flex' : 'none';
}

function showMessage(message, type = 'info') {
    const container = document.getElementById('messageContainer');
    const messageEl = document.createElement('div');
    messageEl.className = `message ${type}`;
    messageEl.innerHTML = `
        <i class="fas fa-${type === 'success' ? 'check' : type === 'error' ? 'exclamation-triangle' : 'info'}"></i>
        <span>${message}</span>
        <button onclick="this.parentElement.remove()">
            <i class="fas fa-times"></i>
        </button>
    `;
    
    container.appendChild(messageEl);
    
    // Auto remove after 5 seconds
    setTimeout(() => {
        if (messageEl.parentElement) {
            messageEl.remove();
        }
    }, 5000);
}

// Search and filter functionality
function setupSearchAndFilters() {
    const productSearch = document.getElementById('productSearch');
    const categoryFilter = document.getElementById('categoryFilter');
    const statusFilter = document.getElementById('statusFilter');
    
    if (productSearch) {
        productSearch.addEventListener('input', filterProducts);
    }
    
    if (categoryFilter) {
        categoryFilter.addEventListener('change', filterProducts);
    }
    
    if (statusFilter) {
        statusFilter.addEventListener('change', filterProducts);
    }
}

function filterProducts() {
    const searchTerm = document.getElementById('productSearch').value.toLowerCase();
    const categoryFilter = document.getElementById('categoryFilter').value;
    const statusFilter = document.getElementById('statusFilter').value;
    
    const rows = document.querySelectorAll('#productsTableBody tr');
    
    rows.forEach(row => {
        const name = row.querySelector('.product-name-cell strong').textContent.toLowerCase();
        const category = row.querySelector('.category-badge').textContent;
        const isActive = row.querySelector('.status-badge.active') !== null;
        const isFeatured = row.querySelector('.status-badge.featured') !== null;
        
        let showRow = true;
        
        // Search filter
        if (searchTerm && !name.includes(searchTerm)) {
            showRow = false;
        }
        
        // Category filter
        if (categoryFilter && category !== categoryFilter) {
            showRow = false;
        }
        
        // Status filter
        if (statusFilter) {
            if (statusFilter === 'active' && !isActive) showRow = false;
            if (statusFilter === 'inactive' && isActive) showRow = false;
            if (statusFilter === 'featured' && !isFeatured) showRow = false;
        }
        
        row.style.display = showRow ? '' : 'none';
    });
}

// Placeholder functions for other sections
function loadOrders() {
    // Placeholder for order management
    console.log('Loading orders...');
}

function loadUsers() {
    // Placeholder for user management
    console.log('Loading users...');
}

function loadAnalytics() {
    // Placeholder for analytics
    console.log('Loading analytics...');
}

function exportData() {
    // Placeholder for data export
    console.log('Exporting data...');
}

function exportOrders() {
    // Placeholder for order export
    console.log('Exporting orders...');
}

function logoutAdmin() {
    if (confirm('Are you sure you want to logout?')) {
        localStorage.removeItem('adminToken');
        localStorage.removeItem('adminUser');
        window.location.href = 'index.html';
    }
}

// Initialize sample data if none exists
function initializeSampleData() {
    if (adminData.products.length === 0) {
        // Add some sample products
        const sampleProducts = [
            {
                id: 1,
                name: 'TSP Classic Black Tee',
                description: 'Premium cotton t-shirt with embroidered TSP logo',
                price: 85.00,
                category: 't-shirts',
                sizes: ['S', 'M', 'L', 'XL'],
                colors: ['Black'],
                stock: 50,
                featured: true,
                active: true,
                image: 'assets/products/tsp-black-tee.jpg',
                placeholder: 'tshirt-black',
                createdAt: new Date().toISOString()
            }
        ];
        
        adminData.products = sampleProducts;
        localStorage.setItem('adminProducts', JSON.stringify(adminData.products));
        updateMainProductsData();
    }
}

// Call initialize sample data
initializeSampleData();