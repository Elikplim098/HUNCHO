// Supabase Client Configuration for Frontend
// This file handles all client-side Supabase operations

// Import Supabase (you'll need to include this via CDN or build process)
// For now, we'll assume it's loaded globally

class SupabaseClient {
    constructor() {
        // These will be set from environment or config
        this.supabaseUrl = window.SUPABASE_URL || 'YOUR_SUPABASE_URL';
        this.supabaseAnonKey = window.SUPABASE_ANON_KEY || 'YOUR_SUPABASE_ANON_KEY';
        
        // Initialize Supabase client when available
        if (typeof supabase !== 'undefined' && this.supabaseUrl && this.supabaseAnonKey) {
            this.client = supabase.createClient(this.supabaseUrl, this.supabaseAnonKey);
            this.initialized = true;
        } else {
            this.initialized = false;
            console.warn('Supabase not initialized. Using fallback to API endpoints.');
        }
        
        this.currentUser = null;
        this.session = null;
        
        // Listen for auth changes
        if (this.initialized) {
            this.client.auth.onAuthStateChange((event, session) => {
                this.session = session;
                this.currentUser = session?.user || null;
                this.handleAuthChange(event, session);
            });
        }
    }

    // Authentication Methods
    async signUp(email, password, userData = {}) {
        if (!this.initialized) {
            return this.fallbackAuth('signup', { email, password, ...userData });
        }

        try {
            const { data, error } = await this.client.auth.signUp({
                email,
                password,
                options: {
                    data: userData
                }
            });

            if (error) throw error;
            return { success: true, data };
        } catch (error) {
            console.error('Signup error:', error);
            return { success: false, error: error.message };
        }
    }

    async signIn(email, password) {
        if (!this.initialized) {
            return this.fallbackAuth('login', { email, password });
        }

        try {
            const { data, error } = await this.client.auth.signInWithPassword({
                email,
                password
            });

            if (error) throw error;
            return { success: true, data };
        } catch (error) {
            console.error('Login error:', error);
            return { success: false, error: error.message };
        }
    }

    async signOut() {
        if (!this.initialized) {
            return this.fallbackAuth('logout');
        }

        try {
            const { error } = await this.client.auth.signOut();
            if (error) throw error;
            return { success: true };
        } catch (error) {
            console.error('Logout error:', error);
            return { success: false, error: error.message };
        }
    }

    // Product Methods
    async getProducts(filters = {}) {
        if (!this.initialized) {
            return this.fallbackAPI('GET', '/api/products', null, filters);
        }

        try {
            let query = this.client
                .from('products')
                .select('*')
                .eq('active', true)
                .order('created_at', { ascending: false });

            if (filters.category) {
                query = query.eq('category', filters.category);
            }

            if (filters.featured) {
                query = query.eq('featured', true);
            }

            if (filters.limit) {
                query = query.limit(filters.limit);
            }

            const { data, error } = await query;
            if (error) throw error;

            return { success: true, products: data };
        } catch (error) {
            console.error('Error fetching products:', error);
            return { success: false, error: error.message };
        }
    }

    async getFeaturedProducts() {
        return this.getProducts({ featured: true, limit: 8 });
    }

    async getProduct(id) {
        if (!this.initialized) {
            return this.fallbackAPI('GET', `/api/products/${id}`);
        }

        try {
            const { data, error } = await this.client
                .from('products')
                .select('*')
                .eq('id', id)
                .eq('active', true)
                .single();

            if (error) throw error;
            return { success: true, product: data };
        } catch (error) {
            console.error('Error fetching product:', error);
            return { success: false, error: error.message };
        }
    }

    // Admin Methods
    async createProduct(productData) {
        if (!this.initialized) {
            return this.fallbackAPI('POST', '/api/admin/products', productData);
        }

        try {
            const { data, error } = await this.client
                .from('products')
                .insert([productData])
                .select()
                .single();

            if (error) throw error;
            return { success: true, product: data };
        } catch (error) {
            console.error('Error creating product:', error);
            return { success: false, error: error.message };
        }
    }

    async updateProduct(id, updates) {
        if (!this.initialized) {
            return this.fallbackAPI('PUT', `/api/admin/products/${id}`, updates);
        }

        try {
            const { data, error } = await this.client
                .from('products')
                .update(updates)
                .eq('id', id)
                .select()
                .single();

            if (error) throw error;
            return { success: true, product: data };
        } catch (error) {
            console.error('Error updating product:', error);
            return { success: false, error: error.message };
        }
    }

    async deleteProduct(id) {
        if (!this.initialized) {
            return this.fallbackAPI('DELETE', `/api/admin/products/${id}`);
        }

        try {
            const { error } = await this.client
                .from('products')
                .delete()
                .eq('id', id);

            if (error) throw error;
            return { success: true };
        } catch (error) {
            console.error('Error deleting product:', error);
            return { success: false, error: error.message };
        }
    }

    // Order Methods
    async createOrder(orderData) {
        if (!this.initialized) {
            return this.fallbackAPI('POST', '/api/orders', orderData);
        }

        try {
            // This would require more complex logic for order items
            // For now, fallback to API
            return this.fallbackAPI('POST', '/api/orders', orderData);
        } catch (error) {
            console.error('Error creating order:', error);
            return { success: false, error: error.message };
        }
    }

    async getOrders() {
        if (!this.initialized) {
            return this.fallbackAPI('GET', '/api/orders');
        }

        try {
            const { data, error } = await this.client
                .from('orders')
                .select(`
                    *,
                    order_items (
                        *,
                        products (*)
                    )
                `)
                .eq('user_id', this.currentUser?.id)
                .order('created_at', { ascending: false });

            if (error) throw error;
            return { success: true, orders: data };
        } catch (error) {
            console.error('Error fetching orders:', error);
            return { success: false, error: error.message };
        }
    }

    // Newsletter subscription
    async subscribeNewsletter(email, name = '') {
        if (!this.initialized) {
            return this.fallbackAPI('POST', '/api/newsletter/subscribe', { email, name });
        }

        try {
            const { data, error } = await this.client
                .from('newsletter_subscribers')
                .insert([{ email, name }])
                .select()
                .single();

            if (error) {
                if (error.code === '23505') {
                    return { success: false, error: 'Email already subscribed' };
                }
                throw error;
            }

            return { success: true, data };
        } catch (error) {
            console.error('Newsletter subscription error:', error);
            return { success: false, error: error.message };
        }
    }

    // Realtime subscriptions
    subscribeToProducts(callback) {
        if (!this.initialized) {
            console.warn('Realtime subscriptions not available without Supabase client');
            return null;
        }

        return this.client
            .channel('products')
            .on('postgres_changes', 
                { event: '*', schema: 'public', table: 'products' }, 
                callback
            )
            .subscribe();
    }

    subscribeToOrders(callback) {
        if (!this.initialized || !this.currentUser) {
            console.warn('Realtime subscriptions not available');
            return null;
        }

        return this.client
            .channel('orders')
            .on('postgres_changes', 
                { 
                    event: '*', 
                    schema: 'public', 
                    table: 'orders',
                    filter: `user_id=eq.${this.currentUser.id}`
                }, 
                callback
            )
            .subscribe();
    }

    // Fallback methods for when Supabase client is not available
    async fallbackAPI(method, endpoint, data = null, params = null) {
        try {
            const url = new URL(endpoint, window.location.origin);
            
            if (params && method === 'GET') {
                Object.keys(params).forEach(key => {
                    if (params[key] !== undefined && params[key] !== null) {
                        url.searchParams.append(key, params[key]);
                    }
                });
            }

            const options = {
                method,
                headers: {
                    'Content-Type': 'application/json',
                }
            };

            if (this.session?.access_token) {
                options.headers.Authorization = `Bearer ${this.session.access_token}`;
            }

            if (data && method !== 'GET') {
                options.body = JSON.stringify(data);
            }

            const response = await fetch(url, options);
            const result = await response.json();

            return result;
        } catch (error) {
            console.error('API fallback error:', error);
            return { success: false, error: error.message };
        }
    }

    async fallbackAuth(action, data) {
        try {
            const response = await fetch(`/api/auth/${action}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(data)
            });

            const result = await response.json();
            
            if (result.success && result.session) {
                this.session = result.session;
                this.currentUser = result.user;
            }

            return result;
        } catch (error) {
            console.error('Auth fallback error:', error);
            return { success: false, error: error.message };
        }
    }

    // Auth state change handler
    handleAuthChange(event, session) {
        console.log('Auth state changed:', event, session);
        
        // Update UI based on auth state
        if (event === 'SIGNED_IN') {
            this.onSignIn(session);
        } else if (event === 'SIGNED_OUT') {
            this.onSignOut();
        }
    }

    onSignIn(session) {
        // Update UI for signed in user
        const loginBtn = document.getElementById('loginBtn');
        const logoutBtn = document.getElementById('logoutBtn');
        
        if (loginBtn) loginBtn.style.display = 'none';
        if (logoutBtn) logoutBtn.style.display = 'block';
        
        // Show success message
        if (typeof showNotification === 'function') {
            showNotification('Successfully signed in!', 'success');
        }
    }

    onSignOut() {
        // Update UI for signed out user
        const loginBtn = document.getElementById('loginBtn');
        const logoutBtn = document.getElementById('logoutBtn');
        const adminBtn = document.getElementById('adminBtn');
        
        if (loginBtn) loginBtn.style.display = 'block';
        if (logoutBtn) logoutBtn.style.display = 'none';
        if (adminBtn) adminBtn.style.display = 'none';
        
        // Show success message
        if (typeof showNotification === 'function') {
            showNotification('Successfully signed out!', 'success');
        }
    }

    // Utility methods
    isAuthenticated() {
        return !!this.currentUser;
    }

    getCurrentUser() {
        return this.currentUser;
    }

    getSession() {
        return this.session;
    }
}

// Initialize global Supabase client
window.supabaseClient = new SupabaseClient();

// Export for module systems
if (typeof module !== 'undefined' && module.exports) {
    module.exports = SupabaseClient;
}