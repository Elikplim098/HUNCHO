// Products page specific functionality
document.addEventListener('DOMContentLoaded', function() {
    loadAdminProductsIfAvailable();
    loadAllProducts();
    setupProductFilters();
});

// Load admin products if available
function loadAdminProductsIfAvailable() {
    const adminProducts = JSON.parse(localStorage.getItem('websiteProducts') || '[]');
    if (adminProducts.length > 0) {
        // Replace existing products with admin products
        allProducts.length = 0;
        allProducts.push(...adminProducts);
        filteredProducts = [...allProducts];
    }
}

// All products data
const allProducts = [
    {
        id: 1,
        name: 'TSP Classic Black Tee',
        description: 'Premium cotton t-shirt with embroidered TSP logo',
        price: 85.00,
        category: 't-shirts',
        image: 'assets/products/tsp-black-tee.jpg',
        placeholder: 'tshirt-black',
        sizes: ['S', 'M', 'L', 'XL'],
        featured: true,
        colors: ['Black']
    },
    {
        id: 2,
        name: 'TSP White Tee',
        description: 'Clean white t-shirt with subtle TSP branding',
        price: 85.00,
        category: 't-shirts',
        image: 'assets/products/tsp-white-tee.jpg',
        placeholder: 'tshirt-white',
        sizes: ['S', 'M', 'L', 'XL'],
        colors: ['White']
    },
    {
        id: 3,
        name: 'TSP Street Hoodie Black',
        description: 'Heavy-weight hoodie with large TSP logo on chest',
        price: 150.00,
        category: 'hoodies',
        image: 'assets/products/tsp-hoodie-black.jpg',
        placeholder: 'hoodie-black',
        sizes: ['M', 'L', 'XL', 'XXL'],
        featured: true,
        colors: ['Black']
    },
    {
        id: 4,
        name: 'TSP Zip Hoodie Grey',
        description: 'Full-zip hoodie with TSP logo and side pockets',
        price: 165.00,
        category: 'hoodies',
        image: 'assets/products/tsp-zip-hoodie-grey.jpg',
        placeholder: 'hoodie-grey',
        sizes: ['M', 'L', 'XL'],
        colors: ['Grey']
    },
    {
        id: 5,
        name: 'TSP Joggers Black',
        description: 'Comfortable joggers with TSP logo on the leg',
        price: 120.00,
        category: 'pants',
        image: 'assets/products/tsp-joggers-black.jpg',
        placeholder: 'joggers-black',
        sizes: ['S', 'M', 'L', 'XL'],
        featured: true,
        colors: ['Black']
    },
    {
        id: 6,
        name: 'TSP Cargo Pants Khaki',
        description: 'Urban cargo pants with multiple pockets and TSP details',
        price: 140.00,
        category: 'pants',
        image: 'assets/products/tsp-cargo-khaki.jpg',
        placeholder: 'cargo-khaki',
        sizes: ['M', 'L', 'XL'],
        colors: ['Khaki']
    },
    {
        id: 7,
        name: 'TSP Snapback Cap Black',
        description: 'Adjustable snapback with embroidered TSP logo',
        price: 65.00,
        category: 'accessories',
        image: 'assets/products/tsp-cap-black.jpg',
        placeholder: 'cap-black',
        sizes: ['One Size'],
        featured: true,
        colors: ['Black']
    },
    {
        id: 8,
        name: 'TSP Beanie Grey',
        description: 'Warm knit beanie with TSP patch',
        price: 45.00,
        category: 'accessories',
        image: 'assets/products/tsp-beanie-grey.jpg',
        placeholder: 'beanie-grey',
        sizes: ['One Size'],
        colors: ['Grey']
    },
    {
        id: 9,
        name: 'TSP Backpack Black',
        description: 'Urban backpack with TSP logo and laptop compartment',
        price: 180.00,
        category: 'accessories',
        image: 'assets/products/tsp-backpack-black.jpg',
        placeholder: 'backpack-black',
        sizes: ['One Size'],
        colors: ['Black']
    },
    {
        id: 10,
        name: 'TSP Tank Top White',
        description: 'Lightweight tank top perfect for summer',
        price: 65.00,
        category: 't-shirts',
        image: 'assets/products/tsp-tank-white.jpg',
        placeholder: 'tank-white',
        sizes: ['S', 'M', 'L', 'XL'],
        colors: ['White']
    },
    {
        id: 11,
        name: 'TSP Sweatshirt Navy',
        description: 'Comfortable crewneck sweatshirt with TSP branding',
        price: 130.00,
        category: 'hoodies',
        image: 'assets/products/tsp-sweatshirt-navy.jpg',
        placeholder: 'sweatshirt-navy',
        sizes: ['M', 'L', 'XL'],
        colors: ['Navy']
    },
    {
        id: 12,
        name: 'TSP Shorts Black',
        description: 'Athletic shorts with TSP logo and side stripes',
        price: 75.00,
        category: 'pants',
        image: 'assets/products/tsp-shorts-black.jpg',
        placeholder: 'shorts-black',
        sizes: ['S', 'M', 'L', 'XL'],
        colors: ['Black']
    },
    {
        id: 13,
        name: 'TSP Oversized Tee Grey',
        description: 'Trendy oversized fit t-shirt with bold TSP graphics',
        price: 95.00,
        category: 't-shirts',
        image: 'assets/products/tsp-oversized-grey.jpg',
        placeholder: 'tshirt-oversized-grey',
        sizes: ['M', 'L', 'XL'],
        colors: ['Grey']
    },
    {
        id: 14,
        name: 'TSP Pullover Hoodie Purple',
        description: 'Comfortable pullover hoodie in signature purple',
        price: 155.00,
        category: 'hoodies',
        image: 'assets/products/tsp-pullover-purple.jpg',
        placeholder: 'hoodie-purple',
        sizes: ['M', 'L', 'XL'],
        colors: ['Purple']
    },
    {
        id: 15,
        name: 'TSP Track Pants Black',
        description: 'Athletic track pants with TSP stripe details',
        price: 110.00,
        category: 'pants',
        image: 'assets/products/tsp-track-black.jpg',
        placeholder: 'track-black',
        sizes: ['S', 'M', 'L', 'XL'],
        colors: ['Black']
    },
    {
        id: 16,
        name: 'TSP Bucket Hat Black',
        description: 'Trendy bucket hat with embroidered TSP logo',
        price: 55.00,
        category: 'accessories',
        image: 'assets/products/tsp-bucket-black.jpg',
        placeholder: 'bucket-black',
        sizes: ['One Size'],
        colors: ['Black']
    }
];

let filteredProducts = [...allProducts];

function loadAllProducts() {
    const productsGrid = document.getElementById('productsGrid');
    if (productsGrid) {
        displayProducts(filteredProducts);
    }
}

function displayProducts(products) {
    const productsGrid = document.getElementById('productsGrid');
    
    if (products.length === 0) {
        productsGrid.innerHTML = `
            <div style="grid-column: 1 / -1; text-align: center; padding: 3rem;">
                <h3>No products found</h3>
                <p>Try adjusting your filters</p>
            </div>
        `;
        return;
    }
    
    productsGrid.innerHTML = products.map(product => {
        // Determine which image to display
        const hasUploadedImage = product.uploaded_images && product.primary_image;
        const displayImage = hasUploadedImage ? product.primary_image : (product.image || 'sp-logo.jpeg');
        const imageClass = hasUploadedImage ? 'uploaded-product-image' : 'placeholder-product-image';
        const showPlaceholder = !hasUploadedImage;
        
        return `
            <div class="product-card" data-category="${product.category}">
                <div class="product-image">
                    ${showPlaceholder ? `
                        <div class="product-placeholder ${product.placeholder || 'default-placeholder'}" data-category="${product.category}">
                            <div class="placeholder-content">
                                <img src="sp-logo.jpeg" alt="TSP Logo" class="placeholder-logo">
                                <div class="placeholder-text">${product.name}</div>
                                <div class="placeholder-category">${product.category.toUpperCase()}</div>
                            </div>
                        </div>
                    ` : ''}
                    <img src="${displayImage}" alt="${product.name}" 
                         class="product-real-image ${imageClass}" 
                         style="${hasUploadedImage ? 'display: block;' : 'display: none;'}"
                         onerror="this.style.display='none'; ${showPlaceholder ? 'this.parentElement.querySelector(\'.product-placeholder\').style.display=\'flex\';' : 'this.src=\'sp-logo.jpeg\'; this.style.display=\'block\';'}"
                         onload="this.style.display='block'; ${showPlaceholder ? 'this.parentElement.querySelector(\'.product-placeholder\').style.display=\'none\';' : ''}">
                    ${product.featured ? '<div class="product-badge">Featured</div>' : ''}
                    ${hasUploadedImage ? '<div class="image-indicator uploaded-indicator" title="Custom uploaded image">📷</div>' : '<div class="image-indicator placeholder-indicator" title="Placeholder image">🖼️</div>'}
                    <div class="product-overlay">
                        <button class="quick-view-btn" onclick="quickView(${product.id})">Quick View</button>
                    </div>
                </div>
                <div class="product-info">
                    <h3>${product.name}</h3>
                    <p>${product.description}</p>
                    <div class="product-price">GH₵ ${product.price.toFixed(2)}</div>
                    <div class="product-meta">
                        <div class="product-sizes">
                            ${product.sizes.map(size => `<span class="size-tag">${size}</span>`).join('')}
                        </div>
                        ${product.colors ? `
                            <div class="product-colors">
                                ${product.colors.map(color => `<span class="color-tag" style="background-color: ${getColorCode(color)}" title="${color}"></span>`).join('')}
                            </div>
                        ` : ''}
                    </div>
                    <button class="add-to-cart-btn" onclick="addToCart(${product.id}, '${product.name}', ${product.price})">
                        Add to Cart
                    </button>
                </div>
            </div>
        `;
    }).join('');
}

function getColorCode(colorName) {
    const colorMap = {
        'Black': '#000000',
        'White': '#FFFFFF',
        'Grey': '#808080',
        'Gray': '#808080',
        'Navy': '#000080',
        'Purple': '#667eea',
        'Khaki': '#C3B091',
        'Blue': '#0066CC'
    };
    return colorMap[colorName] || '#CCCCCC';
}

function quickView(productId) {
    const product = allProducts.find(p => p.id === productId);
    if (product) {
        // Determine which image to display
        const hasUploadedImage = product.uploaded_images && product.primary_image;
        const displayImage = hasUploadedImage ? product.primary_image : (product.image || 'sp-logo.jpeg');
        const showPlaceholder = !hasUploadedImage;
        
        // Create quick view modal
        const modal = document.createElement('div');
        modal.className = 'modal quick-view-modal';
        modal.innerHTML = `
            <div class="modal-content quick-view-content">
                <span class="close">&times;</span>
                <div class="quick-view-grid">
                    <div class="quick-view-image">
                        ${showPlaceholder ? `
                            <div class="product-placeholder ${product.placeholder || 'default-placeholder'}" data-category="${product.category}">
                                <div class="placeholder-content">
                                    <img src="sp-logo.jpeg" alt="TSP Logo" class="placeholder-logo">
                                    <div class="placeholder-text">${product.name}</div>
                                </div>
                            </div>
                        ` : ''}
                        <img src="${displayImage}" alt="${product.name}" 
                             class="product-real-image ${hasUploadedImage ? 'uploaded-product-image' : 'placeholder-product-image'}" 
                             style="${hasUploadedImage ? 'display: block;' : 'display: none;'}"
                             onerror="this.style.display='none'; ${showPlaceholder ? 'this.parentElement.querySelector(\'.product-placeholder\').style.display=\'flex\';' : 'this.src=\'sp-logo.jpeg\'; this.style.display=\'block\';'}"
                             onload="this.style.display='block'; ${showPlaceholder ? 'this.parentElement.querySelector(\'.product-placeholder\').style.display=\'none\';' : ''}">
                        ${hasUploadedImage ? '<div class="image-status-badge">Custom Image</div>' : '<div class="image-status-badge">Placeholder</div>'}
                    </div>
                    <div class="quick-view-details">
                        <h2>${product.name}</h2>
                        <p class="product-description">${product.description}</p>
                        <div class="product-price-large">GH₵ ${product.price.toFixed(2)}</div>
                        <div class="product-options">
                            <div class="size-selection">
                                <label>Size:</label>
                                <select id="quickViewSize">
                                    ${product.sizes.map(size => `<option value="${size}">${size}</option>`).join('')}
                                </select>
                            </div>
                            ${product.colors ? `
                                <div class="color-selection">
                                    <label>Color:</label>
                                    <div class="color-options">
                                        ${product.colors.map(color => `
                                            <span class="color-option" style="background-color: ${getColorCode(color)}" 
                                                  title="${color}" data-color="${color}"></span>
                                        `).join('')}
                                    </div>
                                </div>
                            ` : ''}
                        </div>
                        <button class="add-to-cart-btn large" onclick="addToCart(${product.id}, '${product.name}', ${product.price}); closeModal();">
                            Add to Cart
                        </button>
                    </div>
                </div>
            </div>
        `;
        
        document.body.appendChild(modal);
        modal.style.display = 'block';
        
        // Close modal functionality
        const closeBtn = modal.querySelector('.close');
        closeBtn.onclick = () => closeModal();
        
        window.onclick = (event) => {
            if (event.target === modal) {
                closeModal();
            }
        };
        
        function closeModal() {
            modal.style.display = 'none';
            document.body.removeChild(modal);
        }
    }
}

function setupProductFilters() {
    const categoryFilter = document.getElementById('categoryFilter');
    const sortFilter = document.getElementById('sortFilter');
    
    if (categoryFilter) {
        categoryFilter.addEventListener('change', filterProducts);
    }
    
    if (sortFilter) {
        sortFilter.addEventListener('change', sortProducts);
    }
    
    // Check URL parameters for category filter
    const urlParams = new URLSearchParams(window.location.search);
    const category = urlParams.get('category');
    if (category && categoryFilter) {
        categoryFilter.value = category;
        filterProducts();
    }
}

function filterProducts() {
    const categoryFilter = document.getElementById('categoryFilter');
    const selectedCategory = categoryFilter.value;
    
    if (selectedCategory === '') {
        filteredProducts = [...allProducts];
    } else {
        filteredProducts = allProducts.filter(product => product.category === selectedCategory);
    }
    
    sortProducts();
}

function sortProducts() {
    const sortFilter = document.getElementById('sortFilter');
    const sortBy = sortFilter.value;
    
    switch (sortBy) {
        case 'name':
            filteredProducts.sort((a, b) => a.name.localeCompare(b.name));
            break;
        case 'price-low':
            filteredProducts.sort((a, b) => a.price - b.price);
            break;
        case 'price-high':
            filteredProducts.sort((a, b) => b.price - a.price);
            break;
        default:
            break;
    }
    
    displayProducts(filteredProducts);
}

// Add additional CSS for products page
const productsStyle = document.createElement('style');
productsStyle.textContent = `
    .page-header {
        background: linear-gradient(135deg, #000 0%, #333 100%);
        color: white;
        padding: 8rem 0 4rem;
        text-align: center;
        margin-top: 70px;
    }
    
    .page-header h1 {
        font-size: 3rem;
        margin-bottom: 1rem;
        font-weight: bold;
    }
    
    .page-header p {
        font-size: 1.2rem;
        opacity: 0.9;
    }
    
    .products-section {
        padding: 5rem 0;
        background: white;
    }
    
    .filter-bar {
        display: flex;
        gap: 1rem;
        margin-bottom: 3rem;
        justify-content: center;
        flex-wrap: wrap;
    }
    
    .filter-bar select {
        padding: 0.8rem 1rem;
        border: 2px solid #ddd;
        border-radius: 8px;
        font-size: 1rem;
        background: white;
        cursor: pointer;
        min-width: 150px;
    }
    
    .filter-bar select:focus {
        outline: none;
        border-color: #667eea;
    }
    
    .product-badge {
        position: absolute;
        top: 1rem;
        left: 1rem;
        background: linear-gradient(45deg, #667eea 0%, #764ba2 100%);
        color: white;
        padding: 0.3rem 0.8rem;
        border-radius: 15px;
        font-size: 0.8rem;
        font-weight: 500;
        z-index: 2;
        animation: pulse 2s infinite;
    }
    
    .product-image {
        position: relative;
        overflow: hidden;
        border-radius: 10px 10px 0 0;
    }
    
    .product-real-image {
        width: 100%;
        height: 100%;
        object-fit: cover;
        display: none;
        transition: transform 0.3s ease;
    }
    
    .product-card:hover .product-real-image {
        transform: scale(1.05);
    }
    
    /* Uploaded vs Placeholder Image Styles */
    .uploaded-product-image {
        border: 2px solid #28a745;
        box-shadow: 0 0 10px rgba(40, 167, 69, 0.3);
    }
    
    .placeholder-product-image {
        border: 2px solid #6c757d;
        opacity: 0.9;
    }
    
    /* Image Indicators */
    .image-indicator {
        position: absolute;
        top: 1rem;
        right: 1rem;
        width: 30px;
        height: 30px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 0.8rem;
        z-index: 3;
        cursor: help;
    }
    
    .uploaded-indicator {
        background: linear-gradient(45deg, #28a745 0%, #20c997 100%);
        color: white;
        box-shadow: 0 2px 8px rgba(40, 167, 69, 0.3);
    }
    
    .placeholder-indicator {
        background: linear-gradient(45deg, #6c757d 0%, #495057 100%);
        color: white;
        box-shadow: 0 2px 8px rgba(108, 117, 125, 0.3);
    }
    
    .image-status-badge {
        position: absolute;
        bottom: 1rem;
        right: 1rem;
        background: rgba(0, 0, 0, 0.8);
        color: white;
        padding: 0.3rem 0.6rem;
        border-radius: 12px;
        font-size: 0.7rem;
        font-weight: 500;
        z-index: 2;
    }
    
    /* Product Placeholder Styles */
    .product-placeholder {
        width: 100%;
        height: 100%;
        display: flex;
        align-items: center;
        justify-content: center;
        position: relative;
        overflow: hidden;
        background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
    }
    
    .product-placeholder::before {
        content: '';
        position: absolute;
        top: 0;
        left: -100%;
        width: 100%;
        height: 100%;
        background: linear-gradient(90deg, transparent, rgba(102, 126, 234, 0.1), transparent);
        animation: shimmer 2s infinite;
    }
    
    .placeholder-content {
        text-align: center;
        z-index: 1;
    }
    
    .placeholder-logo {
        width: 80px;
        height: 80px;
        margin-bottom: 1rem;
        opacity: 0.7;
        border-radius: 8px;
    }
    
    .placeholder-text {
        font-size: 0.9rem;
        font-weight: 600;
        color: #333;
        margin-bottom: 0.5rem;
        max-width: 200px;
        line-height: 1.2;
    }
    
    .placeholder-category {
        font-size: 0.7rem;
        color: #666;
        text-transform: uppercase;
        letter-spacing: 1px;
        background: linear-gradient(45deg, #667eea 0%, #764ba2 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
        font-weight: 500;
    }
    
    /* Category-specific placeholder colors */
    .product-placeholder[data-category="t-shirts"] {
        background: linear-gradient(135deg, #e3f2fd 0%, #bbdefb 100%);
    }
    
    .product-placeholder[data-category="hoodies"] {
        background: linear-gradient(135deg, #f3e5f5 0%, #e1bee7 100%);
    }
    
    .product-placeholder[data-category="pants"] {
        background: linear-gradient(135deg, #e8f5e8 0%, #c8e6c9 100%);
    }
    
    .product-placeholder[data-category="accessories"] {
        background: linear-gradient(135deg, #fff3e0 0%, #ffcc02 100%);
    }
    
    .default-placeholder {
        background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
    }
    
    .product-overlay {
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: rgba(0,0,0,0.7);
        display: flex;
        align-items: center;
        justify-content: center;
        opacity: 0;
        transition: opacity 0.3s ease;
    }
    
    .product-card:hover .product-overlay {
        opacity: 1;
    }
    
    .quick-view-btn {
        background: linear-gradient(45deg, #667eea 0%, #764ba2 100%);
        color: white;
        border: none;
        padding: 0.8rem 1.5rem;
        border-radius: 25px;
        cursor: pointer;
        font-weight: 500;
        transition: transform 0.3s ease;
    }
    
    .quick-view-btn:hover {
        transform: scale(1.05);
    }
    
    .product-meta {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin: 1rem 0;
        flex-wrap: wrap;
        gap: 1rem;
    }
    
    .product-sizes {
        display: flex;
        gap: 0.5rem;
        flex-wrap: wrap;
    }
    
    .size-tag {
        padding: 0.2rem 0.5rem;
        background: #f0f0f0;
        border-radius: 3px;
        font-size: 0.8rem;
        border: 1px solid #ddd;
        transition: all 0.3s ease;
    }
    
    .size-tag:hover {
        background: linear-gradient(45deg, #667eea 0%, #764ba2 100%);
        color: white;
        border-color: transparent;
    }
    
    .product-colors {
        display: flex;
        gap: 0.3rem;
    }
    
    .color-tag {
        width: 20px;
        height: 20px;
        border-radius: 50%;
        border: 2px solid #ddd;
        cursor: pointer;
        transition: transform 0.3s ease;
    }
    
    .color-tag:hover {
        transform: scale(1.2);
        border-color: #667eea;
    }
    
    /* Quick View Modal */
    .quick-view-modal .modal-content {
        max-width: 800px;
        width: 90%;
    }
    
    .quick-view-grid {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 2rem;
        align-items: start;
    }
    
    .quick-view-image {
        position: relative;
        height: 400px;
        border-radius: 10px;
        overflow: hidden;
    }
    
    .quick-view-details h2 {
        margin-bottom: 1rem;
        color: #333;
    }
    
    .product-description {
        color: #666;
        margin-bottom: 1.5rem;
        line-height: 1.6;
    }
    
    .product-price-large {
        font-size: 1.8rem;
        font-weight: bold;
        background: linear-gradient(45deg, #667eea 0%, #764ba2 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
        margin-bottom: 1.5rem;
    }
    
    .product-options {
        margin-bottom: 2rem;
    }
    
    .size-selection,
    .color-selection {
        margin-bottom: 1rem;
    }
    
    .size-selection label,
    .color-selection label {
        display: block;
        margin-bottom: 0.5rem;
        font-weight: 500;
        color: #333;
    }
    
    .size-selection select {
        padding: 0.5rem;
        border: 2px solid #ddd;
        border-radius: 5px;
        font-size: 1rem;
        min-width: 120px;
    }
    
    .color-options {
        display: flex;
        gap: 0.5rem;
    }
    
    .color-option {
        width: 30px;
        height: 30px;
        border-radius: 50%;
        border: 3px solid #ddd;
        cursor: pointer;
        transition: all 0.3s ease;
    }
    
    .color-option:hover,
    .color-option.selected {
        border-color: #667eea;
        transform: scale(1.1);
    }
    
    .add-to-cart-btn.large {
        width: 100%;
        padding: 1rem;
        font-size: 1.1rem;
    }
    
    @keyframes shimmer {
        0% { left: -100%; }
        100% { left: 100%; }
    }
    
    @keyframes pulse {
        0%, 100% { transform: scale(1); }
        50% { transform: scale(1.05); }
    }
    
    /* Image Upload Status Animations */
    .uploaded-indicator {
        animation: uploadSuccess 1s ease-in-out;
    }
    
    @keyframes uploadSuccess {
        0% { transform: scale(0); opacity: 0; }
        50% { transform: scale(1.2); opacity: 1; }
        100% { transform: scale(1); opacity: 1; }
    }
    
    /* Hover effects for uploaded images */
    .product-card:hover .uploaded-product-image {
        border-color: #20c997;
        box-shadow: 0 0 15px rgba(32, 201, 151, 0.4);
    }
    
    @media (max-width: 768px) {
        .page-header h1 {
            font-size: 2rem;
        }
        
        .filter-bar {
            flex-direction: column;
            align-items: center;
        }
        
        .filter-bar select {
            width: 100%;
            max-width: 300px;
        }
        
        .quick-view-grid {
            grid-template-columns: 1fr;
            gap: 1rem;
        }
        
        .quick-view-image {
            height: 300px;
        }
        
        .product-meta {
            flex-direction: column;
            align-items: flex-start;
        }
        
        .image-indicator {
            width: 25px;
            height: 25px;
            font-size: 0.7rem;
        }
    }
`;
document.head.appendChild(productsStyle);