// Simple file-based user storage system
// This is a fallback when Supabase is not available

const fs = require('fs');
const path = require('path');
const bcrypt = require('bcryptjs');

const USERS_FILE = path.join(__dirname, 'data', 'users.json');

// Ensure data directory exists
function ensureDataDirectory() {
    const dataDir = path.dirname(USERS_FILE);
    if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
    }
}

// Load users from file
function loadUsers() {
    ensureDataDirectory();
    
    try {
        if (fs.existsSync(USERS_FILE)) {
            const data = fs.readFileSync(USERS_FILE, 'utf8');
            return JSON.parse(data);
        }
    } catch (error) {
        console.error('Error loading users:', error);
    }
    
    return [];
}

// Save users to file
function saveUsers(users) {
    ensureDataDirectory();
    
    try {
        fs.writeFileSync(USERS_FILE, JSON.stringify(users, null, 2));
        return true;
    } catch (error) {
        console.error('Error saving users:', error);
        return false;
    }
}

// Create a new user
async function createUser(email, password, name) {
    const users = loadUsers();
    
    // Check if user already exists
    const existingUser = users.find(u => u.email === email);
    if (existingUser) {
        throw new Error('User already exists');
    }
    
    // Hash password
    const hashedPassword = await bcrypt.hash(password, 10);
    
    // Create new user
    const newUser = {
        id: 'local_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9),
        email,
        name: name || null,
        password: hashedPassword,
        role: 'customer',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
    };
    
    users.push(newUser);
    
    if (saveUsers(users)) {
        // Return user without password
        const { password: _, ...userWithoutPassword } = newUser;
        return userWithoutPassword;
    } else {
        throw new Error('Failed to save user');
    }
}

// Authenticate user
async function authenticateUser(email, password) {
    const users = loadUsers();
    
    // Find user by email
    const user = users.find(u => u.email === email);
    if (!user) {
        throw new Error('Invalid email or password');
    }
    
    // Check password
    const passwordMatch = await bcrypt.compare(password, user.password);
    if (!passwordMatch) {
        throw new Error('Invalid email or password');
    }
    
    // Return user without password
    const { password: _, ...userWithoutPassword } = user;
    return userWithoutPassword;
}

// Get user by ID
function getUserById(id) {
    const users = loadUsers();
    const user = users.find(u => u.id === id);
    
    if (user) {
        const { password: _, ...userWithoutPassword } = user;
        return userWithoutPassword;
    }
    
    return null;
}

// Get user by email
function getUserByEmail(email) {
    const users = loadUsers();
    const user = users.find(u => u.email === email);
    
    if (user) {
        const { password: _, ...userWithoutPassword } = user;
        return userWithoutPassword;
    }
    
    return null;
}

// Update user
function updateUser(id, updates) {
    const users = loadUsers();
    const userIndex = users.findIndex(u => u.id === id);
    
    if (userIndex === -1) {
        throw new Error('User not found');
    }
    
    // Update user data
    users[userIndex] = {
        ...users[userIndex],
        ...updates,
        updated_at: new Date().toISOString()
    };
    
    if (saveUsers(users)) {
        const { password: _, ...userWithoutPassword } = users[userIndex];
        return userWithoutPassword;
    } else {
        throw new Error('Failed to update user');
    }
}

// Delete user
function deleteUser(id) {
    const users = loadUsers();
    const userIndex = users.findIndex(u => u.id === id);
    
    if (userIndex === -1) {
        throw new Error('User not found');
    }
    
    users.splice(userIndex, 1);
    
    if (saveUsers(users)) {
        return true;
    } else {
        throw new Error('Failed to delete user');
    }
}

// Get all users (admin only)
function getAllUsers() {
    const users = loadUsers();
    return users.map(user => {
        const { password: _, ...userWithoutPassword } = user;
        return userWithoutPassword;
    });
}

module.exports = {
    createUser,
    authenticateUser,
    getUserById,
    getUserByEmail,
    updateUser,
    deleteUser,
    getAllUsers
};