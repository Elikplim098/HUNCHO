const express = require('express');
const serverless = require('serverless-http');
const cors = require('cors');
const path = require('path');
const { createClient } = require('@supabase/supabase-js');
require('dotenv').config();

const app = express();

// Initialize Supabase client
const supabaseUrl = process.env.SUPABASE_URL;
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
const supabaseAnonKey = process.env.SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseServiceKey) {
    console.error('Missing Supabase configuration');
}

const supabaseAdmin = createClient(supabaseUrl, supabaseServiceKey);
const supabase = createClient(supabaseUrl, supabaseAnonKey);

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Add Supabase client to request object
app.use((req, res, next) => {
    req.supabase = supabase;
    req.supabaseAdmin = supabaseAdmin;
    next();
});

// Authentication middleware
const authenticateUser = async (req, res, next) => {
    const token = req.headers.authorization?.replace('Bearer ', '');
    
    if (!token) {
        return res.status(401).json({ success: false, message: 'No token provided' });
    }
    
    try {
        const { data: { user }, error } = await supabase.auth.getUser(token);
        
        if (error || !user) {
            return res.status(401).json({ success: false, message: 'Invalid token' });
        }
        
        req.user = user;
        next();
    } catch (error) {
        return res.status(401).json({ success: false, message: 'Authentication failed' });
    }
};

// Admin middleware
const requireAdmin = async (req, res, next) => {
    if (!req.user) {
        return res.status(401).json({ success: false, message: 'Authentication required' });
    }
    
    try {
        const { data: userData, error } = await supabaseAdmin
            .from('users')
            .select('role')
            .eq('id', req.user.id)
            .single();
        
        if (error || userData?.role !== 'admin') {
            return res.status(403).json({ success: false, message: 'Admin access required' });
        }
        
        next();
    } catch (error) {
        return res.status(500).json({ success: false, message: 'Authorization check failed' });
    }
};

// Health check endpoint
app.get('/health', (req, res) => {
    res.json({ 
        success: true, 
        message: 'TSP API is running on Netlify',
        timestamp: new Date().toISOString(),
        supabase: {
            url: supabaseUrl ? 'configured' : 'missing',
            connected: true
        }
    });
});

// Products API Routes
app.get('/products', async (req, res) => {
    try {
        const { category, featured, limit } = req.query;
        
        let query = supabase
            .from('products')
            .select('*')
            .eq('active', true)
            .order('created_at', { ascending: false });
        
        if (category) {
            query = query.eq('category', category);
        }
        
        if (featured === 'true') {
            query = query.eq('featured', true);
        }
        
        if (limit) {
            query = query.limit(parseInt(limit));
        }
        
        const { data: products, error } = await query;
        
        if (error) {
            throw error;
        }
        
        res.json({ success: true, products });
    } catch (error) {
        console.error('Error fetching products:', error);
        res.status(500).json({ success: false, message: 'Failed to fetch products' });
    }
});

app.get('/products/featured', async (req, res) => {
    try {
        const { data: products, error } = await supabase
            .from('products')
            .select('*')
            .eq('featured', true)
            .eq('active', true)
            .limit(8)
            .order('created_at', { ascending: false });
        
        if (error) {
            throw error;
        }
        
        res.json({ success: true, products });
    } catch (error) {
        console.error('Error fetching featured products:', error);
        res.status(500).json({ success: false, message: 'Failed to fetch featured products' });
    }
});

// Admin login route
app.post('/auth/admin-login', async (req, res) => {
    try {
        const { username, password } = req.body;
        
        if (username === 'admin' && password === 'admin123') {
            const adminToken = 'admin-token-' + Date.now();
            
            res.json({
                success: true,
                user: {
                    id: 'admin',
                    username: 'admin',
                    name: 'Administrator',
                    role: 'admin',
                    isAdmin: true
                },
                token: adminToken,
                message: 'Admin login successful'
            });
        } else {
            res.status(401).json({ success: false, message: 'Invalid admin credentials' });
        }
    } catch (error) {
        console.error('Admin login error:', error);
        res.status(500).json({ success: false, message: 'Admin login failed' });
    }
});

// Newsletter subscription
app.post('/newsletter/subscribe', async (req, res) => {
    try {
        const { email, name } = req.body;
        
        const { data, error } = await supabaseAdmin
            .from('newsletter_subscribers')
            .insert([{ email, name }])
            .select()
            .single();
        
        if (error) {
            if (error.code === '23505') {
                return res.status(400).json({ success: false, message: 'Email already subscribed' });
            }
            throw error;
        }
        
        res.json({ success: true, message: 'Successfully subscribed to newsletter' });
    } catch (error) {
        console.error('Newsletter subscription error:', error);
        res.status(500).json({ success: false, message: 'Failed to subscribe' });
    }
});

// Error handler
app.use((error, req, res, next) => {
    console.error('Server error:', error);
    res.status(500).json({ success: false, message: 'Internal server error' });
});

// Export the serverless function
module.exports.handler = serverless(app);