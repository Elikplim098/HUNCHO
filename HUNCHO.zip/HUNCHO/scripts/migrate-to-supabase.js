// Migration script to move data from localStorage/MongoDB to Supabase
const { createClient } = require('@supabase/supabase-js');
require('dotenv').config();

const supabaseUrl = process.env.SUPABASE_URL;
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

if (!supabaseUrl || !supabaseServiceKey) {
    console.error('❌ Missing Supabase configuration in .env file');
    process.exit(1);
}

const supabase = createClient(supabaseUrl, supabaseServiceKey);

// Sample products data (replace with your actual data)
const sampleProducts = [
    {
        name: 'TSP Classic Black Tee',
        description: 'Premium cotton t-shirt with embroidered TSP logo. Made from 100% organic cotton for ultimate comfort and style.',
        price: 85.00,
        category: 't-shirts',
        sizes: ['S', 'M', 'L', 'XL'],
        colors: ['Black'],
        primary_image: 'assets/products/tsp-black-tee.jpg',
        images: ['assets/products/tsp-black-tee.jpg', 'assets/products/tsp-black-tee-back.jpg'],
        stock: 50,
        featured: true,
        active: true,
        sku: 'TSP-TEE-001',
        tags: ['tshirt', 'black', 'classic', 'cotton']
    },
    {
        name: 'TSP White Logo Tee',
        description: 'Clean white tee with TSP branding. Perfect for everyday wear with a minimalist design.',
        price: 85.00,
        category: 't-shirts',
        sizes: ['S', 'M', 'L', 'XL'],
        colors: ['White'],
        primary_image: 'assets/products/tsp-white-tee.jpg',
        images: ['assets/products/tsp-white-tee.jpg'],
        stock: 45,
        featured: true,
        active: true,
        sku: 'TSP-TEE-002',
        tags: ['tshirt', 'white', 'logo', 'cotton']
    },
    {
        name: 'TSP Oversized Hoodie',
        description: 'Comfortable oversized hoodie with TSP graphics. Perfect for layering and street style.',
        price: 150.00,
        category: 'hoodies',
        sizes: ['S', 'M', 'L', 'XL'],
        colors: ['Black', 'Grey'],
        primary_image: 'assets/products/tsp-hoodie.jpg',
        images: ['assets/products/tsp-hoodie.jpg', 'assets/products/tsp-hoodie-grey.jpg'],
        stock: 30,
        featured: true,
        active: true,
        sku: 'TSP-HOOD-001',
        tags: ['hoodie', 'oversized', 'streetwear', 'comfortable']
    },
    {
        name: 'TSP Cargo Pants',
        description: 'Stylish cargo pants with TSP details. Functional pockets meet street fashion.',
        price: 120.00,
        category: 'pants',
        sizes: ['28', '30', '32', '34', '36'],
        colors: ['Black', 'Khaki'],
        primary_image: 'assets/products/tsp-cargo.jpg',
        images: ['assets/products/tsp-cargo.jpg', 'assets/products/tsp-cargo-khaki.jpg'],
        stock: 25,
        featured: false,
        active: true,
        sku: 'TSP-PANT-001',
        tags: ['pants', 'cargo', 'functional', 'streetwear']
    },
    {
        name: 'TSP Snapback Cap',
        description: 'Classic snapback cap with embroidered TSP logo. One size fits all.',
        price: 65.00,
        category: 'accessories',
        sizes: ['One Size'],
        colors: ['Black', 'White', 'Grey'],
        primary_image: 'assets/products/tsp-cap.jpg',
        images: ['assets/products/tsp-cap.jpg', 'assets/products/tsp-cap-white.jpg'],
        stock: 40,
        featured: false,
        active: true,
        sku: 'TSP-ACC-001',
        tags: ['cap', 'snapback', 'accessory', 'logo']
    },
    {
        name: 'TSP Tote Bag',
        description: 'Durable canvas tote bag with TSP branding. Perfect for daily use.',
        price: 45.00,
        category: 'accessories',
        sizes: ['One Size'],
        colors: ['Black', 'Natural'],
        primary_image: 'assets/products/tsp-tote.jpg',
        images: ['assets/products/tsp-tote.jpg', 'assets/products/tsp-tote-natural.jpg'],
        stock: 35,
        featured: false,
        active: true,
        sku: 'TSP-ACC-002',
        tags: ['bag', 'tote', 'canvas', 'practical']
    }
];

async function migrateProducts() {
    console.log('🚀 Starting product migration to Supabase...');
    
    try {
        // Check if products already exist
        const { data: existingProducts, error: checkError } = await supabase
            .from('products')
            .select('sku')
            .limit(1);
        
        if (checkError) {
            console.error('❌ Error checking existing products:', checkError.message);
            return;
        }
        
        if (existingProducts && existingProducts.length > 0) {
            console.log('⚠️  Products already exist in database. Skipping migration.');
            console.log('   To force migration, delete existing products first.');
            return;
        }
        
        // Insert sample products
        const { data: insertedProducts, error: insertError } = await supabase
            .from('products')
            .insert(sampleProducts)
            .select();
        
        if (insertError) {
            console.error('❌ Error inserting products:', insertError.message);
            return;
        }
        
        console.log(`✅ Successfully migrated ${insertedProducts.length} products to Supabase!`);
        
        // Display migrated products
        insertedProducts.forEach(product => {
            console.log(`   - ${product.name} (${product.sku})`);
        });
        
    } catch (error) {
        console.error('❌ Migration failed:', error.message);
    }
}

async function createAdminUser() {
    console.log('👤 Creating admin user...');
    
    try {
        // Create admin user in auth
        const { data: authData, error: authError } = await supabase.auth.admin.createUser({
            email: 'admin@thestreetpays.com',
            password: 'admin123',
            email_confirm: true
        });
        
        if (authError) {
            console.error('❌ Error creating admin auth user:', authError.message);
            return;
        }
        
        // Create admin profile
        const { data: profileData, error: profileError } = await supabase
            .from('users')
            .insert([{
                id: authData.user.id,
                email: authData.user.email,
                name: 'Administrator',
                role: 'admin'
            }])
            .select()
            .single();
        
        if (profileError) {
            console.error('❌ Error creating admin profile:', profileError.message);
            return;
        }
        
        console.log('✅ Admin user created successfully!');
        console.log('   Email: admin@thestreetpays.com');
        console.log('   Password: admin123');
        console.log('   Role: admin');
        
    } catch (error) {
        console.error('❌ Admin user creation failed:', error.message);
    }
}

async function testConnection() {
    console.log('🔍 Testing Supabase connection...');
    
    try {
        const { data, error } = await supabase
            .from('products')
            .select('count(*)')
            .single();
        
        if (error) {
            console.error('❌ Connection test failed:', error.message);
            return false;
        }
        
        console.log('✅ Supabase connection successful!');
        return true;
    } catch (error) {
        console.error('❌ Connection test failed:', error.message);
        return false;
    }
}

async function main() {
    console.log('🏪 TSP Clothing Brand - Supabase Migration');
    console.log('==========================================');
    
    // Test connection first
    const connected = await testConnection();
    if (!connected) {
        console.log('\n❌ Migration aborted due to connection issues.');
        console.log('   Please check your Supabase configuration in .env file.');
        process.exit(1);
    }
    
    console.log('');
    
    // Migrate products
    await migrateProducts();
    
    console.log('');
    
    // Create admin user
    await createAdminUser();
    
    console.log('');
    console.log('🎉 Migration completed!');
    console.log('');
    console.log('Next steps:');
    console.log('1. Update your .env file with Supabase credentials');
    console.log('2. Run: npm run start:supabase');
    console.log('3. Visit: http://localhost:3000');
    console.log('4. Test admin login with: admin@thestreetpays.com / admin123');
    
    process.exit(0);
}

// Run migration
main().catch(console.error);