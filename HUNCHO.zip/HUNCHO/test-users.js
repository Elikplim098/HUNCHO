// Simple test script to verify user storage system
const userStorage = require('./user-storage');

async function testUserStorage() {
    console.log('🧪 Testing User Storage System');
    console.log('==============================');
    
    try {
        // Test 1: Create a new user
        console.log('\n1. Creating a new user...');
        const newUser = await userStorage.createUser('test@example.com', 'password123', 'Test User');
        console.log('✅ User created:', newUser);
        
        // Test 2: Try to create duplicate user (should fail)
        console.log('\n2. Trying to create duplicate user...');
        try {
            await userStorage.createUser('test@example.com', 'password456', 'Duplicate User');
            console.log('❌ Should have failed');
        } catch (error) {
            console.log('✅ Correctly rejected duplicate:', error.message);
        }
        
        // Test 3: Authenticate user with correct password
        console.log('\n3. Authenticating with correct password...');
        const authenticatedUser = await userStorage.authenticateUser('test@example.com', 'password123');
        console.log('✅ Authentication successful:', authenticatedUser);
        
        // Test 4: Try to authenticate with wrong password
        console.log('\n4. Trying to authenticate with wrong password...');
        try {
            await userStorage.authenticateUser('test@example.com', 'wrongpassword');
            console.log('❌ Should have failed');
        } catch (error) {
            console.log('✅ Correctly rejected wrong password:', error.message);
        }
        
        // Test 5: Get user by ID
        console.log('\n5. Getting user by ID...');
        const userById = userStorage.getUserById(newUser.id);
        console.log('✅ User found by ID:', userById);
        
        // Test 6: Get user by email
        console.log('\n6. Getting user by email...');
        const userByEmail = userStorage.getUserByEmail('test@example.com');
        console.log('✅ User found by email:', userByEmail);
        
        // Test 7: Update user
        console.log('\n7. Updating user...');
        const updatedUser = userStorage.updateUser(newUser.id, { name: 'Updated Test User' });
        console.log('✅ User updated:', updatedUser);
        
        // Test 8: Get all users
        console.log('\n8. Getting all users...');
        const allUsers = userStorage.getAllUsers();
        console.log('✅ All users:', allUsers);
        
        // Test 9: Delete user
        console.log('\n9. Deleting user...');
        const deleted = userStorage.deleteUser(newUser.id);
        console.log('✅ User deleted:', deleted);
        
        // Test 10: Verify user is deleted
        console.log('\n10. Verifying user is deleted...');
        const deletedUser = userStorage.getUserById(newUser.id);
        console.log('✅ User not found (as expected):', deletedUser);
        
        console.log('\n🎉 All tests passed!');
        
    } catch (error) {
        console.error('❌ Test failed:', error);
    }
}

// Run tests
testUserStorage();