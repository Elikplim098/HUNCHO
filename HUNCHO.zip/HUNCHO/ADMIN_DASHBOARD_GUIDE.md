# TSP Admin Dashboard Guide

## Overview
The admin dashboard provides a comprehensive interface for managing The Street Pays website, including product management, order tracking, user management, and analytics.

## Access & Authentication

### Demo Credentials
- **URL**: `http://localhost:3000/admin.html`
- **Email**: `admin@thestreetpays.com`
- **Password**: `admin123`

### Login Process
1. Click "Login" on any page
2. Enter admin credentials
3. Click "Login as Admin"
4. Access "Admin" button that appears
5. Navigate to admin dashboard

## Dashboard Features

### 🏠 Dashboard Overview
- **Real-time Statistics**: Products, orders, users, revenue
- **Recent Activity**: Latest system activities
- **Quick Actions**: Fast access to common tasks
- **Visual Analytics**: Charts and graphs (placeholder for future)

### 📦 Product Management

#### Adding New Products
1. Navigate to "Products" section
2. Click "Add New Product"
3. Fill in product details:
   - **Name**: Product title
   - **Category**: T-Shirts, Hoodies, Pants, Accessories
   - **Price**: In Ghana Cedis (GH₵)
   - **Description**: Detailed product description
   - **Sizes**: Comma-separated (S,M,L,XL)
   - **Colors**: Comma-separated (Black,White,Grey)
   - **Stock**: Available quantity
   - **Images**: Upload up to 5 images (5MB each)
   - **Featured**: Mark as featured product
   - **Active**: Publish/unpublish product

#### Product Features
- **Image Upload**: Drag & drop or click to upload
- **Image Preview**: Real-time preview of uploaded images
- **Automatic Placeholders**: CSS-based placeholders if no image
- **Category Badges**: Color-coded category indicators
- **Stock Management**: Track inventory levels
- **Status Control**: Active/inactive and featured toggles

#### Product Actions
- **Edit**: Modify existing products
- **Toggle Status**: Activate/deactivate products
- **Delete**: Remove products (with confirmation)
- **Search & Filter**: Find products by name, category, status

### 🛒 Order Management
- **Order Tracking**: View all customer orders
- **Status Updates**: Pending, Processing, Shipped, Delivered
- **Customer Information**: Contact details and order history
- **Export Orders**: Download order data

### 👥 User Management
- **User Accounts**: View registered users
- **Role Management**: Admin and customer roles
- **Account Status**: Active/inactive users
- **Registration Tracking**: User signup dates

### 📊 Analytics & Reports
- **Sales Overview**: Revenue trends and patterns
- **Top Products**: Best-selling items
- **Customer Insights**: User behavior analytics
- **Revenue Trends**: Financial performance tracking

## Technical Implementation

### Frontend Architecture
- **HTML**: Semantic, accessible admin interface
- **CSS**: Modern, responsive design with loading theme
- **JavaScript**: Vanilla JS with modular functions
- **LocalStorage**: Client-side data persistence
- **File Upload**: Drag & drop image handling

### Backend Integration
- **Express.js**: RESTful API endpoints
- **Multer**: File upload handling
- **Image Processing**: Automatic resizing and optimization
- **Data Validation**: Input sanitization and validation

### Data Management
- **Products**: JSON structure with full metadata
- **Images**: File system storage with URL references
- **Placeholders**: CSS-generated fallback images
- **Sync**: Real-time sync between admin and website

## API Endpoints

### Products API
```
GET    /api/products          - Get all products
GET    /api/products/featured - Get featured products
GET    /api/products/:id      - Get single product
POST   /api/products          - Add new product
PUT    /api/products/:id      - Update product
DELETE /api/products/:id      - Delete product
```

### Request Examples

#### Add Product
```javascript
POST /api/products
Content-Type: multipart/form-data

{
  name: "TSP New Product",
  description: "Product description",
  price: 99.00,
  category: "t-shirts",
  sizes: "S,M,L,XL",
  colors: "Black,White",
  stock: 50,
  featured: true,
  active: true,
  images: [File objects]
}
```

#### Update Product
```javascript
PUT /api/products/123
Content-Type: multipart/form-data

{
  name: "Updated Product Name",
  price: 89.00,
  stock: 25
}
```

## File Structure

### Admin Files
```
public/
├── admin.html          # Admin dashboard interface
├── admin.js           # Admin functionality
├── styles.css         # Includes admin styles
└── assets/
    └── products/      # Product image storage

routes/
└── products.js        # Product API endpoints
```

### Key Components
- **Navigation**: Multi-section admin navigation
- **Forms**: Dynamic product creation/editing
- **Tables**: Sortable, filterable data tables
- **Modals**: Overlay forms and confirmations
- **Notifications**: Success/error messaging
- **File Upload**: Drag & drop image handling

## Security Features

### Authentication
- **Session Management**: Token-based authentication
- **Role Verification**: Admin-only access control
- **Auto Logout**: Session timeout handling

### Data Protection
- **Input Validation**: Server-side validation
- **File Type Checking**: Image-only uploads
- **Size Limits**: 5MB per image maximum
- **XSS Prevention**: Input sanitization

### Access Control
- **Admin Routes**: Protected admin endpoints
- **CSRF Protection**: Request validation
- **Rate Limiting**: API request throttling

## Customization

### Styling
- **CSS Variables**: Easy color scheme changes
- **Responsive Design**: Mobile-friendly interface
- **Loading Theme**: Purple-blue gradient system
- **Dark Mode**: Automatic system preference detection

### Functionality
- **Custom Fields**: Add new product attributes
- **Validation Rules**: Custom input validation
- **File Processing**: Image optimization settings
- **Export Formats**: CSV, JSON, PDF options

## Troubleshooting

### Common Issues

#### Login Problems
- **Invalid Credentials**: Check demo credentials
- **Session Expired**: Clear localStorage and retry
- **Browser Cache**: Hard refresh (Ctrl+F5)

#### Upload Issues
- **File Too Large**: Maximum 5MB per image
- **Invalid Format**: Only JPG, PNG, WebP allowed
- **Network Error**: Check server connection

#### Display Problems
- **Missing Images**: Check file paths and permissions
- **Layout Issues**: Clear browser cache
- **JavaScript Errors**: Check browser console

### Debug Mode
Enable debug logging:
```javascript
localStorage.setItem('adminDebug', 'true');
```

### Performance Tips
- **Image Optimization**: Compress images before upload
- **Batch Operations**: Process multiple items together
- **Cache Management**: Clear old data periodically
- **Browser Memory**: Refresh page for large datasets

## Future Enhancements

### Planned Features
- **Bulk Import**: CSV product import
- **Image Editor**: Built-in image editing tools
- **Inventory Alerts**: Low stock notifications
- **Sales Reports**: Advanced analytics dashboard
- **Multi-language**: Internationalization support

### Integration Options
- **Payment Gateway**: Stripe, PayPal integration
- **Shipping API**: Automated shipping calculations
- **Email Marketing**: Newsletter integration
- **Social Media**: Auto-posting to social platforms
- **Analytics**: Google Analytics integration

## Support

### Documentation
- **API Reference**: Detailed endpoint documentation
- **Video Tutorials**: Step-by-step guides
- **Best Practices**: Recommended workflows
- **FAQ**: Common questions and answers

### Contact
For technical support or feature requests:
- **Email**: admin@thestreetpays.com
- **Documentation**: Check this guide first
- **Issues**: Report bugs and feature requests

## Changelog

### Version 1.0.0
- Initial admin dashboard release
- Product management system
- Image upload functionality
- Responsive design implementation
- Authentication system
- API endpoints creation

### Future Versions
- Enhanced analytics dashboard
- Order management system
- User management interface
- Advanced reporting features
- Mobile app integration