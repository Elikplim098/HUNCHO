const express = require('express');
const router = express.Router();

// Simple auth routes for demo purposes
router.post('/login', (req, res) => {
    const { email, password } = req.body;
    
    // Simple demo authentication
    if (email && password) {
        const user = {
            id: 1,
            email: email,
            isAdmin: email.includes('admin')
        };
        
        res.json({
            success: true,
            user: user,
            message: 'Login successful'
        });
    } else {
        res.status(400).json({
            success: false,
            message: 'Email and password required'
        });
    }
});

router.post('/register', (req, res) => {
    const { username, email, password } = req.body;
    
    if (username && email && password) {
        const user = {
            id: Date.now(),
            username: username,
            email: email,
            isAdmin: false
        };
        
        res.json({
            success: true,
            user: user,
            message: 'Registration successful'
        });
    } else {
        res.status(400).json({
            success: false,
            message: 'All fields required'
        });
    }
});

module.exports = router;