const express = require('express');
const router = express.Router();
const multer = require('multer');
const path = require('path');

// Configure multer for file uploads
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, 'public/assets/products/');
    },
    filename: function (req, file, cb) {
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
        cb(null, file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname));
    }
});

const upload = multer({ 
    storage: storage,
    limits: {
        fileSize: 5 * 1024 * 1024 // 5MB limit
    },
    fileFilter: function (req, file, cb) {
        const allowedTypes = /jpeg|jpg|png|webp/;
        const extname = allowedTypes.test(path.extname(file.originalname).toLowerCase());
        const mimetype = allowedTypes.test(file.mimetype);
        
        if (mimetype && extname) {
            return cb(null, true);
        } else {
            cb(new Error('Only image files are allowed'));
        }
    }
});

// Sample products data (in production, this would be in a database)
let products = [
    {
        id: 1,
        name: 'TSP Classic Black Tee',
        description: 'Premium cotton t-shirt with embroidered TSP logo',
        price: 85.00,
        category: 't-shirts',
        image: 'assets/products/tsp-black-tee.jpg',
        placeholder: 'tshirt-black',
        sizes: ['S', 'M', 'L', 'XL'],
        colors: ['Black'],
        stock: 50,
        featured: true,
        active: true,
        createdAt: new Date().toISOString()
    },
    {
        id: 2,
        name: 'TSP Street Hoodie Black',
        description: 'Heavy-weight hoodie with large TSP logo on chest',
        price: 150.00,
        category: 'hoodies',
        image: 'assets/products/tsp-hoodie-black.jpg',
        placeholder: 'hoodie-black',
        sizes: ['M', 'L', 'XL'],
        colors: ['Black'],
        stock: 30,
        featured: true,
        active: true,
        createdAt: new Date().toISOString()
    }
];

// Get all products
router.get('/', (req, res) => {
    const { category, featured, active } = req.query;
    let filteredProducts = [...products];
    
    if (category) {
        filteredProducts = filteredProducts.filter(p => p.category === category);
    }
    
    if (featured === 'true') {
        filteredProducts = filteredProducts.filter(p => p.featured);
    }
    
    if (active === 'true') {
        filteredProducts = filteredProducts.filter(p => p.active);
    }
    
    res.json({
        success: true,
        products: filteredProducts,
        total: filteredProducts.length
    });
});

// Get featured products
router.get('/featured', (req, res) => {
    const featuredProducts = products.filter(product => product.featured && product.active);
    res.json({
        success: true,
        products: featuredProducts
    });
});

// Get single product
router.get('/:id', (req, res) => {
    const product = products.find(p => p.id === parseInt(req.params.id));
    
    if (!product) {
        return res.status(404).json({
            success: false,
            message: 'Product not found'
        });
    }
    
    res.json({
        success: true,
        product
    });
});

// Add new product (admin only)
router.post('/', upload.array('images', 5), (req, res) => {
    try {
        const {
            name,
            description,
            price,
            category,
            sizes,
            colors,
            stock,
            featured,
            active
        } = req.body;
        
        // Process uploaded files
        const imageUrls = req.files ? req.files.map(file => `/assets/products/${file.filename}`) : [];
        
        const newProduct = {
            id: Date.now(),
            name,
            description,
            price: parseFloat(price),
            category,
            sizes: sizes ? sizes.split(',').map(s => s.trim()) : [],
            colors: colors ? colors.split(',').map(c => c.trim()) : [],
            stock: parseInt(stock) || 0,
            featured: featured === 'true' || featured === true,
            active: active === 'true' || active === true,
            images: imageUrls,
            image: imageUrls[0] || `assets/products/${name.toLowerCase().replace(/[^a-z0-9]/g, '-')}.jpg`,
            placeholder: generatePlaceholder(category, name),
            createdAt: new Date().toISOString()
        };
        
        products.push(newProduct);
        
        res.json({
            success: true,
            product: newProduct,
            message: 'Product added successfully'
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
});

// Update product (admin only)
router.put('/:id', upload.array('images', 5), (req, res) => {
    try {
        const productId = parseInt(req.params.id);
        const productIndex = products.findIndex(p => p.id === productId);
        
        if (productIndex === -1) {
            return res.status(404).json({
                success: false,
                message: 'Product not found'
            });
        }
        
        const {
            name,
            description,
            price,
            category,
            sizes,
            colors,
            stock,
            featured,
            active
        } = req.body;
        
        // Process uploaded files
        const imageUrls = req.files ? req.files.map(file => `/assets/products/${file.filename}`) : [];
        
        const updatedProduct = {
            ...products[productIndex],
            name: name || products[productIndex].name,
            description: description || products[productIndex].description,
            price: price ? parseFloat(price) : products[productIndex].price,
            category: category || products[productIndex].category,
            sizes: sizes ? sizes.split(',').map(s => s.trim()) : products[productIndex].sizes,
            colors: colors ? colors.split(',').map(c => c.trim()) : products[productIndex].colors,
            stock: stock !== undefined ? parseInt(stock) : products[productIndex].stock,
            featured: featured !== undefined ? (featured === 'true' || featured === true) : products[productIndex].featured,
            active: active !== undefined ? (active === 'true' || active === true) : products[productIndex].active,
            images: imageUrls.length > 0 ? imageUrls : products[productIndex].images,
            image: imageUrls.length > 0 ? imageUrls[0] : products[productIndex].image,
            updatedAt: new Date().toISOString()
        };
        
        products[productIndex] = updatedProduct;
        
        res.json({
            success: true,
            product: updatedProduct,
            message: 'Product updated successfully'
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
});

// Delete product (admin only)
router.delete('/:id', (req, res) => {
    try {
        const productId = parseInt(req.params.id);
        const productIndex = products.findIndex(p => p.id === productId);
        
        if (productIndex === -1) {
            return res.status(404).json({
                success: false,
                message: 'Product not found'
            });
        }
        
        const deletedProduct = products.splice(productIndex, 1)[0];
        
        res.json({
            success: true,
            product: deletedProduct,
            message: 'Product deleted successfully'
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
});

// Helper function to generate placeholder name
function generatePlaceholder(category, name) {
    const categoryMap = {
        't-shirts': 'tshirt',
        'hoodies': 'hoodie',
        'pants': 'pants',
        'accessories': 'accessory'
    };
    
    const baseCategory = categoryMap[category] || 'product';
    const cleanName = name.toLowerCase().replace(/[^a-z0-9]/g, '-');
    return `${baseCategory}-${cleanName}`;
}

module.exports = router;