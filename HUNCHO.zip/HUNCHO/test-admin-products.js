// Test admin product creation
const fetch = (...args) => import('node-fetch').then(({default: fetch}) => fetch(...args));

const BASE_URL = 'http://localhost:3002';

async function testAdminProducts() {
    console.log('🧪 Testing Admin Product Management');
    console.log('==================================');
    
    try {
        // Test 1: Admin login to get token
        console.log('\n1. Testing admin login...');
        const adminResponse = await fetch(`${BASE_URL}/api/auth/admin-login`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                username: 'admin',
                password: 'admin123'
            })
        });
        
        const adminData = await adminResponse.json();
        console.log('✅ Admin login response:', adminData);
        
        if (!adminData.success) {
            throw new Error('Admin login failed: ' + adminData.message);
        }
        
        const adminToken = adminData.token;
        
        // Test 2: Create a product
        console.log('\n2. Testing product creation...');
        const productData = {
            name: 'Test TSP T-Shirt',
            description: 'A test t-shirt for the admin system',
            price: 75.00,
            category: 't-shirts',
            sizes: ['S', 'M', 'L', 'XL'],
            colors: ['Black', 'White'],
            stock: 25,
            featured: true,
            active: true
        };
        
        const createResponse = await fetch(`${BASE_URL}/api/admin/products`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${adminToken}`
            },
            body: JSON.stringify(productData)
        });
        
        const createResult = await createResponse.json();
        console.log('✅ Product creation response:', createResult);
        
        if (!createResult.success) {
            throw new Error('Product creation failed: ' + createResult.message);
        }
        
        const productId = createResult.product.id;
        
        // Test 3: Update the product
        console.log('\n3. Testing product update...');
        const updateResponse = await fetch(`${BASE_URL}/api/admin/products/${productId}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${adminToken}`
            },
            body: JSON.stringify({
                price: 80.00,
                stock: 30
            })
        });
        
        const updateResult = await updateResponse.json();
        console.log('✅ Product update response:', updateResult);
        
        // Test 4: Get all products to verify
        console.log('\n4. Testing product retrieval...');
        const getResponse = await fetch(`${BASE_URL}/api/products`);
        const getResult = await getResponse.json();
        console.log('✅ Products retrieved:', getResult.products?.length || 0, 'products');
        
        // Test 5: Delete the product
        console.log('\n5. Testing product deletion...');
        const deleteResponse = await fetch(`${BASE_URL}/api/admin/products/${productId}`, {
            method: 'DELETE',
            headers: {
                'Authorization': `Bearer ${adminToken}`
            }
        });
        
        const deleteResult = await deleteResponse.json();
        console.log('✅ Product deletion response:', deleteResult);
        
        console.log('\n🎉 All admin product tests passed!');
        
    } catch (error) {
        console.error('❌ Test failed:', error.message);
    }
}

// Run tests
testAdminProducts();