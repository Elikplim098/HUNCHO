const express = require('express');
const cors = require('cors');
const path = require('path');
const userStorage = require('./user-storage');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3001;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'));

// Simple admin authentication check
function isAdminToken(token) {
    return token && token.startsWith('admin-token-');
}

// Health check endpoint
app.get('/api/health', (req, res) => {
    res.json({ 
        success: true, 
        message: 'TSP API is running',
        timestamp: new Date().toISOString(),
        userStorage: {
            type: 'Local File Storage',
            available: true
        }
    });
});

// Products API Routes
app.get('/api/products', async (req, res) => {
    try {
        // Get products from localStorage or return sample products
        const sampleProducts = [
            {
                id: 1,
                name: 'TSP Classic Black Tee',
                description: 'Premium cotton t-shirt with embroidered TSP logo',
                price: 85.00,
                category: 't-shirts',
                sizes: ['S', 'M', 'L', 'XL'],
                colors: ['Black'],
                primary_image: 'assets/products/tsp-black-tee.jpg',
                stock: 50,
                featured: true,
                active: true
            },
            {
                id: 2,
                name: 'TSP White Logo Tee',
                description: 'Clean white tee with TSP branding',
                price: 85.00,
                category: 't-shirts',
                sizes: ['S', 'M', 'L', 'XL'],
                colors: ['White'],
                primary_image: 'assets/products/tsp-white-tee.jpg',
                stock: 45,
                featured: true,
                active: true
            }
        ];
        
        res.json({ success: true, products: sampleProducts });
    } catch (error) {
        console.error('Error fetching products:', error);
        res.status(500).json({ success: false, message: 'Failed to fetch products' });
    }
});

app.get('/api/products/featured', async (req, res) => {
    try {
        const sampleProducts = [
            {
                id: 1,
                name: 'TSP Classic Black Tee',
                description: 'Premium cotton t-shirt with embroidered TSP logo',
                price: 85.00,
                category: 't-shirts',
                sizes: ['S', 'M', 'L', 'XL'],
                colors: ['Black'],
                primary_image: 'assets/products/tsp-black-tee.jpg',
                stock: 50,
                featured: true,
                active: true
            }
        ];
        
        res.json({ success: true, products: sampleProducts });
    } catch (error) {
        console.error('Error fetching featured products:', error);
        res.status(500).json({ success: false, message: 'Failed to fetch featured products' });
    }
});

// Authentication Routes
app.post('/api/auth/signup', async (req, res) => {
    try {
        const { email, password, name } = req.body;
        
        if (!email || !password) {
            return res.status(400).json({ success: false, message: 'Email and password are required' });
        }
        
        if (password.length < 6) {
            return res.status(400).json({ success: false, message: 'Password must be at least 6 characters long' });
        }
        
        const newUser = await userStorage.createUser(email, password, name);
        const sessionToken = 'local_session_' + Date.now() + '_' + newUser.id;
        
        res.json({
            success: true,
            user: newUser,
            session: {
                access_token: sessionToken,
                user: newUser
            },
            message: 'User created successfully'
        });
        
    } catch (error) {
        console.error('Signup error:', error);
        res.status(400).json({ success: false, message: error.message });
    }
});

app.post('/api/auth/login', async (req, res) => {
    try {
        const { email, password } = req.body;
        
        if (!email || !password) {
            return res.status(400).json({ success: false, message: 'Email and password are required' });
        }
        
        const user = await userStorage.authenticateUser(email, password);
        const sessionToken = 'local_session_' + Date.now() + '_' + user.id;
        
        res.json({
            success: true,
            user: user,
            session: {
                access_token: sessionToken,
                user: user
            },
            message: 'Login successful'
        });
        
    } catch (error) {
        console.error('Login error:', error);
        res.status(401).json({ success: false, message: error.message });
    }
});

app.post('/api/auth/logout', async (req, res) => {
    try {
        res.json({ success: true, message: 'Logout successful' });
    } catch (error) {
        console.error('Logout error:', error);
        res.status(400).json({ success: false, message: error.message });
    }
});

// Admin login route
app.post('/api/auth/admin-login', async (req, res) => {
    try {
        const { username, password } = req.body;
        
        if (username === 'admin' && password === 'admin123') {
            const adminToken = 'admin-token-' + Date.now();
            
            res.json({
                success: true,
                user: {
                    id: 'admin',
                    username: 'admin',
                    name: 'Administrator',
                    role: 'admin',
                    isAdmin: true
                },
                token: adminToken,
                message: 'Admin login successful'
            });
        } else {
            res.status(401).json({ success: false, message: 'Invalid admin credentials' });
        }
    } catch (error) {
        console.error('Admin login error:', error);
        res.status(500).json({ success: false, message: 'Admin login failed' });
    }
});

// Admin Products Routes
app.post('/api/admin/products', async (req, res) => {
    try {
        const authHeader = req.headers.authorization;
        
        if (!authHeader || !authHeader.startsWith('Bearer ')) {
            return res.status(401).json({ success: false, message: 'Admin authentication required' });
        }
        
        const token = authHeader.replace('Bearer ', '');
        
        if (!isAdminToken(token)) {
            return res.status(401).json({ success: false, message: 'Invalid admin token' });
        }
        
        const productData = {
            ...req.body,
            id: 'product_' + Date.now(),
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString()
        };
        
        console.log('Creating product:', productData);
        
        res.json({ success: true, product: productData, message: 'Product created successfully' });
        
    } catch (error) {
        console.error('Error creating product:', error);
        res.status(500).json({ success: false, message: 'Failed to create product' });
    }
});

app.put('/api/admin/products/:id', async (req, res) => {
    try {
        const authHeader = req.headers.authorization;
        
        if (!authHeader || !authHeader.startsWith('Bearer ')) {
            return res.status(401).json({ success: false, message: 'Admin authentication required' });
        }
        
        const token = authHeader.replace('Bearer ', '');
        
        if (!isAdminToken(token)) {
            return res.status(401).json({ success: false, message: 'Invalid admin token' });
        }
        
        const updates = {
            ...req.body,
            updated_at: new Date().toISOString()
        };
        
        console.log('Updating product:', req.params.id, updates);
        
        res.json({ success: true, product: { id: req.params.id, ...updates }, message: 'Product updated successfully' });
        
    } catch (error) {
        console.error('Error updating product:', error);
        res.status(500).json({ success: false, message: 'Failed to update product' });
    }
});

app.delete('/api/admin/products/:id', async (req, res) => {
    try {
        const authHeader = req.headers.authorization;
        
        if (!authHeader || !authHeader.startsWith('Bearer ')) {
            return res.status(401).json({ success: false, message: 'Admin authentication required' });
        }
        
        const token = authHeader.replace('Bearer ', '');
        
        if (!isAdminToken(token)) {
            return res.status(401).json({ success: false, message: 'Invalid admin token' });
        }
        
        console.log('Deleting product:', req.params.id);
        
        res.json({ success: true, message: 'Product deleted successfully' });
        
    } catch (error) {
        console.error('Error deleting product:', error);
        res.status(500).json({ success: false, message: 'Failed to delete product' });
    }
});

// Newsletter subscription
app.post('/api/newsletter/subscribe', async (req, res) => {
    try {
        const { email, name } = req.body;
        
        console.log('Newsletter subscription:', { email, name });
        
        res.json({ success: true, message: 'Successfully subscribed to newsletter' });
    } catch (error) {
        console.error('Newsletter subscription error:', error);
        res.status(500).json({ success: false, message: 'Failed to subscribe' });
    }
});

// Serve static files
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// 404 handler
app.use('*', (req, res) => {
    res.status(404).json({ success: false, message: 'Route not found' });
});

// Error handler
app.use((error, req, res, next) => {
    console.error('Server error:', error);
    res.status(500).json({ success: false, message: 'Internal server error' });
});

app.listen(PORT, () => {
    console.log(`🚀 TSP Server running on port ${PORT}`);
    console.log(`📊 Using local file storage for users`);
    console.log(`🔑 Admin credentials: admin / admin123`);
    console.log(`🌐 Visit: http://localhost:${PORT}`);
});

module.exports = app;