# Supabase Integration Setup Guide for TSP Clothing Brand

## 🚀 Quick Start

### Step 1: Create Supabase Project

1. Go to [supabase.com](https://supabase.com) and sign up/login
2. Click "New Project"
3. Choose your organization
4. Enter project details:
   - **Name**: `tsp-clothing-brand`
   - **Database Password**: Create a strong password
   - **Region**: Choose closest to your users (e.g., `us-east-1`)
5. Click "Create new project"
6. Wait for project to initialize (2-3 minutes)

### Step 2: Get Project Credentials

1. In your Supabase dashboard, go to **Settings** → **API**
2. Copy the following values:
   - **Project URL** (looks like: `https://your-project-ref.supabase.co`)
   - **Anon/Public Key** (starts with `eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...`)
   - **Service Role Key** (starts with `eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...`)

### Step 3: Update Environment Variables

1. Open your `.env` file
2. Replace the placeholder values:

```env
SUPABASE_URL=https://your-project-ref.supabase.co
SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...your-anon-key
SUPABASE_SERVICE_ROLE_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...your-service-role-key
```

### Step 4: Set Up Database Schema

1. In Supabase dashboard, go to **SQL Editor**
2. Copy the entire contents of `database-schema.sql`
3. Paste into the SQL Editor
4. Click **Run** to execute the schema
5. Verify tables were created in **Table Editor**

### Step 5: Update Your Server

1. **Option A: Use new Supabase server (Recommended)**
   ```bash
   # Rename current server
   mv server.js server-mongodb.js
   
   # Use Supabase server
   mv server-supabase.js server.js
   ```

2. **Option B: Keep both servers**
   - Keep `server.js` as is
   - Use `server-supabase.js` by running: `node server-supabase.js`

### Step 6: Add Supabase Client to Frontend

1. Add Supabase CDN to your HTML files (add before closing `</head>` tag):

```html
<script src="https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2"></script>
<script>
  // Set Supabase config for client
  window.SUPABASE_URL = 'YOUR_SUPABASE_URL';
  window.SUPABASE_ANON_KEY = 'YOUR_SUPABASE_ANON_KEY';
</script>
<script src="supabase-client.js"></script>
```

2. Update your HTML files:
   - `public/index.html`
   - `public/products.html`
   - `public/about.html`
   - `public/contact.html`
   - `public/admin.html`

## 🔧 Configuration Options

### Authentication Setup

1. In Supabase dashboard, go to **Authentication** → **Settings**
2. Configure:
   - **Site URL**: `http://localhost:3000` (for development)
   - **Redirect URLs**: Add your production domain when ready
   - Enable **Email confirmations** if desired

### Row Level Security (RLS)

The schema includes RLS policies for:
- ✅ Users can only see their own data
- ✅ Products are public for reading
- ✅ Orders are private to users
- ✅ Admin users can manage all data

### Storage Setup (Optional)

For product images:

1. Go to **Storage** in Supabase dashboard
2. Create a bucket named `product-images`
3. Set bucket to **Public** for product images
4. Update your admin panel to upload images to Supabase Storage

## 🧪 Testing the Integration

### 1. Test Database Connection

```bash
node server.js
# Visit http://localhost:3000/api/health
# Should show Supabase connection status
```

### 2. Test Products API

```bash
# Get all products
curl http://localhost:3000/api/products

# Get featured products
curl http://localhost:3000/api/products/featured
```

### 3. Test Admin Login

1. Visit `http://localhost:3000`
2. Click "Login"
3. Use credentials: `admin` / `admin123`
4. Should redirect to admin dashboard

### 4. Test Product Management

1. Login as admin
2. Go to admin dashboard
3. Try adding a new product
4. Verify it appears in the products list

## 🔄 Migration from MongoDB

If you were using MongoDB before:

### Data Migration

1. Export your existing MongoDB data:
   ```bash
   mongoexport --db thestreetpays --collection products --out products.json
   ```

2. Convert and import to Supabase:
   - Use the Supabase dashboard **Table Editor**
   - Or write a migration script using the Supabase client

### Update Code References

1. Replace MongoDB queries with Supabase queries
2. Update authentication to use Supabase Auth
3. Replace Mongoose models with Supabase table operations

## 🚀 Production Deployment

### Environment Variables

Set these in your production environment:

```env
NODE_ENV=production
SUPABASE_URL=https://your-project-ref.supabase.co
SUPABASE_ANON_KEY=your-production-anon-key
SUPABASE_SERVICE_ROLE_KEY=your-production-service-role-key
```

### Security Checklist

- ✅ RLS policies are enabled
- ✅ Service role key is kept secret
- ✅ CORS is configured properly
- ✅ Authentication is required for admin operations
- ✅ Input validation is in place

### Performance Optimization

1. **Database Indexes**: Already included in schema
2. **Connection Pooling**: Supabase handles this
3. **Caching**: Consider adding Redis for frequently accessed data
4. **CDN**: Use Supabase Storage with CDN for images

## 🛠️ Advanced Features

### Real-time Updates

Enable real-time product updates:

```javascript
// In your frontend
const subscription = supabaseClient.subscribeToProducts((payload) => {
  console.log('Product updated:', payload);
  // Update UI automatically
});
```

### File Upload

For product images:

```javascript
// Upload to Supabase Storage
const { data, error } = await supabase.storage
  .from('product-images')
  .upload(`products/${productId}/${fileName}`, file);
```

### Analytics

Track user behavior:

```javascript
// Custom events
await supabase
  .from('analytics_events')
  .insert([{
    event_type: 'product_view',
    product_id: productId,
    user_id: userId
  }]);
```

## 🆘 Troubleshooting

### Common Issues

1. **"Invalid API key"**
   - Check your `.env` file has correct keys
   - Ensure no extra spaces in the keys

2. **"Table doesn't exist"**
   - Run the `database-schema.sql` in Supabase SQL Editor
   - Check table names match exactly

3. **"RLS policy violation"**
   - Check user is authenticated
   - Verify RLS policies allow the operation

4. **"CORS error"**
   - Add your domain to Supabase Auth settings
   - Check CORS configuration in your server

### Getting Help

- 📚 [Supabase Documentation](https://supabase.com/docs)
- 💬 [Supabase Discord](https://discord.supabase.com)
- 🐛 [GitHub Issues](https://github.com/supabase/supabase/issues)

## 📈 Next Steps

After basic setup:

1. **Add Image Upload**: Implement Supabase Storage for product images
2. **Email Templates**: Customize auth emails in Supabase dashboard
3. **Webhooks**: Set up webhooks for order notifications
4. **Analytics**: Add custom analytics tracking
5. **Mobile App**: Use same Supabase backend for mobile app

---

## 🎉 You're All Set!

Your TSP Clothing Brand website is now powered by Supabase! You have:

- ✅ Scalable PostgreSQL database
- ✅ Built-in authentication
- ✅ Real-time capabilities
- ✅ File storage ready
- ✅ Admin dashboard
- ✅ API endpoints
- ✅ Row-level security

Happy coding! 🚀